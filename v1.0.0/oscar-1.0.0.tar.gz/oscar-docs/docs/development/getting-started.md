# Oscar Developer Guide

## Local Development

### Overview

The `build.py` script provides a utility to automate the process of building various components of the Oscar Application, packaging them, and preparing them for deployment. The script offers flexibility in building specific components or the entire application.

### Prerequisites

- Ensure Docker is installed and running on your machine.
- Clone main oscar git repository:

  ```bash
  git clone git@github.com:cmetech/oscar.git
  ```

  or https clone option:

  ```bash
  git clone https://github.com/cmetech/oscar.git
  ```

- Make sure you have Python and the required libraries installed (see `requirements.txt`).

  ```bash
  cd oscar
  pip install -r requirements.txt
  ```

### How to Build Application for Local Development

1. **Clone the Supplemental and Optional Repositories**:

  Note: Make sure you are one-level up from the oscar folder.

   ```bash
   cd ..
   git clone git@github.com:cmetech/locust.git oscar-locust
   git clone git@github.com:cmetech/oscar-ehexporter.git
   git clone git@github.com:cmetech/oscar-nifi.git
   git clone git@github.com:cmetech/oscar-ehdatagen.git
   git clone git@github.com:cmetech/oscar-adminui.git
   git clone git@github.com:cmetech/oscar-ui.git
   ```

   or https clone option:

   ```bash
   git clone https://github.com/cmetech/locust.git oscar-locust
   git clone https://github.com/cmetech/oscar-ehexporter.git
   git clone https://github.com/cmetech/oscar-nifi.git
   git clone https://github.com/cmetech/oscar-ehdatagen.git
   git clone https://github.com/cmetech/oscar-adminui.git
   git clone https://github.com/cmetech/oscar-ui.git
   ```

   Note: The supplemental repositories are separate repositories that contain the Dockerfiles and other files needed to build the various components of the Oscar Application.  The supplemental repositories are not included in the main Oscar repository because they are 3rd party or custom code for certain components of the oscar application.

   Final directory structure should look like this:

   ```bash
    oscar
      oscar-middleware
      oscar-frontend
      oscar-{datastore,metricstore,logstore,alertmanager,workflow,reverseproxy,exporters}
    oscar-adminui
    oscar-ehdatagen
    oscar-ehexporter
    oscar-locust
    oscar-nifi
    oscar-ui
  ```

2. **Perform Build Tasks**:

  - **Help**:

    To see all available options:

    ```bash
    cd oscar
    python build.py -h
    ```

  - **Build Everything**:

    This command will build all components.

    ```bash
    cd oscar
    python build.py --full --version 'v1.0.0' --verbose
    ```

  - **Build a Specific Component**:

    To build only a specific component (e.g., `nifi`, `ui`, `locust`, `ehexporter`, `adminui`):

    ```bash
    cd oscar
    python build.py --build locust -a 'amd64' --version 'v1.0.0' --verbose
    python build.py --build ui -v '10.0.3' -a 'arm64' --verbose --args 'VERSION=10.0.3'
    python build.py --build nifi --version 'v1.0.0' --verbose
    python build.py --build ehexporter --version 'v1.0.0' --verbose
    python build.py --build adminui --version 'v1.0.0' --verbose
    ```

    To build multiple components, separate them with a space:

    ```bash
    cd oscar
    python build.py --build nifi ehexporter adminui --version 'v1.0.0' --verbose
    ```

    Note: Some images must be built with amd64 architecture.  If you are building on an arm64 machine, you must specify the `--arch amd64` flag.

    The `--version` flag is optional. If not specified, the latest version will be used.
    The `--verbose` flag is optional. If specified, the build process will be more verbose.

  - **Clean Up**:

    This will remove built images and temporary files from previous builds.
    ```bash
    cd oscar
    python build.py --clean
    python build.py --clean nifi ehexporter adminui
    python build.py --clean --full
    ```

  - **Remove All Images**:

    This will remove all Docker images from your machine except the ones identified in the EXCLUDE LIST.

    ```bash
    cd oscar
    python build.py --remove
    ```
### How to configure application for local development
To configure application for local development please follow initialization script:

1. Run initialization script
```bash
cd oscar
./oscar clean
./oscar init development
```

Note: This script will create perform the following actions:
- Create Docker network
- Copy environment files to correct locations
- Generate secrets
- Touch .env file


### How to run application for local development
To run application for local development please follow the steps below:

1a. Start the application (all components)
```bash
```bash
cd oscar
./oscar start
```

1b. Start the application (individual components)

```bash
cd oscar
./oscar start datastore
./oscar start metricstore
./oscar start logstore
./oscar start alertmanager
./oscar start backend
./oscar start workflow
./oscar start frontend
./oscar start reverseproxy
./oscar start exporters
```


2a. Stop the application (all components)
```bash
cd oscar
./oscar stop
```

2b. Stop the application (individual components) - reverse order of start

```bash
cd oscar
./oscar stop exporters
./oscar stop reverseproxy
./oscar stop frontend
./oscar stop workflow
./oscar stop backend
./oscar stop alertmanager
./oscar stop logstore
./oscar stop metricstore
./oscar stop datastore
```


#### Notes



## Deployment

# Oscar Installation Guide

# Pre-requisites

Oscar requires the following directory to be created on your system for the log object store:

```bash
mkdir -p /opt/oscar-data
```

Follow the steps below to set up Oscar:

## 1. Extract the Oscar Lite Archive

First, we need to extract the main `oscar` archive:

```bash
tar -xzvf oscar.tar.gz
```

## 2. Extract the Oscar Application

Next, let's extract the `oscar-app` archive:

```bash
tar -xzvf oscar-app-x.y.z.tar.gz
```

## 3. Initialize Oscar

Finally, navigate to the extracted `oscar-app` folder and initialize Oscar:

```bash
cd oscar-x.y.z
./oscar init
```

## 4. Start Oscar

To start Oscar, run the following command:

```bash
./oscar start
```

# Ansible

## Running Ansible Playbooks

To run an Ansible playbook, run the following command:

```bash
ansible-playbook -i inventory playbook.yml -u <username> --ask-pass
```

# Job Scheduling Configuration

This section describes how to configure job scheduling in Oscar.

## Structure of the Job Scheduling YAML Configuration File

Each job scheduling configuration file is a YAML file with the following structure:

```yaml
- name: category:name
  status: "enabled"  # or "disabled"
  owner: "Owner Name"
  organization: "Organization Name"
  description: "Description of the job"
  schedule:
    # Schedule details (see below)
  args:
    # Arguments (key-value pairs or key-array)
  hosts:
    - "host1"
    - "host2"
```

### Required Properties

- `name`: The name of the job, in the format `category:name`. The `category` and `name` are used to uniquely identify the job. The `category` must be one of `monitor`, `tasks`, or `utils`.

- `status`: The status of the job, which can be either `enabled` or `disabled`.

### Optional Properties

- `owner`: The name of the owner of the job.
- `organization`: The name of the organization that owns the job.
- `description`: A description of the job.
- `schedule`: The schedule details for the job (see below). Defines when the job should run. This is a dictionary where each key is a schedule type (e.g., `minute`, `hour`, `day`, etc.) and the value is the schedule details for that type. Valid values inclue:
    - `minute`: A minute value (0-59) or `*` for any minute.
    - `hour`: An hour value (0-23) or `*` for any hour.
    - `day`: A day value (1-31) or `*` for any day.
    - `month`: A month value (1-12) or `*` for any month.
    - `weekday`: A weekday value (0-6) or `*` for any weekday.
- `args`: The arguments for the job (key-value pairs or key-array).
- `hosts`: The hosts on which the job should run.

## Example Job Scheduling Configuration File

Here is an example job scheduling configuration file with Key-Value args:

```yaml
- name: tasks:user_info
  status: "enabled"
  owner: "John Doe"
  organization: "Magenta Tools Team"
  description: "Check users info on the system"
  schedule:
    minute: "*/5"
  args:
    userid: "johndoe"
  hosts: ["10.10.0.247"]
```

Here is an example job scheduling configuration file with Key-Array args:

```yaml
- name: monitor:check_processes
  status: "enabled"
  owner: "John Doe"
  organization: "Magenta Tools Team"
  description: "Check if processes are running"
  schedule:
    minute: "*/5"
  args:
    process_names: ["node_exporter"]
  hosts: ["10.10.0.247"]
```




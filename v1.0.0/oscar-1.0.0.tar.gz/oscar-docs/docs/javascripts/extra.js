document.addEventListener('DOMContentLoaded', function () {
  const params = new URLSearchParams(window.location.search);
  const theme = params.get('theme');
  if (theme === 'dark') {
    // Logic to activate the dark mode
    document.body.setAttribute('data-md-color-scheme', 'oscar-dark');
  } else if (theme === 'light') {
    // Logic to activate the light mode
    document.body.setAttribute('data-md-color-scheme', 'oscar-light');
  }
});

document.addEventListener('DOMContentLoaded', function () {
  const params = new URLSearchParams(window.location.search);
  const theme = params.get('theme');

  if (theme) {
    localStorage.setItem('mkdocs-theme', theme);
    switchTheme(theme);
  } else {
    const storedTheme = localStorage.getItem('mkdocs-theme');
    if (storedTheme) {
      switchTheme(storedTheme);
    }
  }
});

function switchTheme(theme) {
  console.log('Switching theme to', theme);
  const themeSwitchers = document.querySelectorAll('input[name="__palette"]');
  themeSwitchers.forEach((switcher) => {
    if (switcher.dataset.mdColorScheme === theme) {
      switcher.checked = true;
      switcher.dispatchEvent(new Event('change'));
    }
  });

  if (theme === 'dark') {
    // Logic to activate the dark mode
    document.body.setAttribute('data-md-color-scheme', 'oscar-dark');
  } else if (theme === 'light') {
    // Logic to activate the light mode
    document.body.setAttribute('data-md-color-scheme', 'oscar-light');
  }
}

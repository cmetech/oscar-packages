from enum import Enum
from pydantic import BaseModel, Field, root_validator, TypeAdapter, ValidationError
from typing import List, TypeVar, Any, Dict, Union, Optional
from zoneinfo import ZoneInfo
from datetime import datetime
import logging

logger = logging.getLogger('oscar-metricstore')


class TimezoneAwareBaseModel(BaseModel):
    @root_validator(pre=True)
    def ensure_all_datetimes_are_timezone_aware(cls, values: Union[Dict[str, Any], 'TimezoneAwareBaseModel']):
        # If values is an instance of the model, convert to dict first
        if isinstance(values, TimezoneAwareBaseModel):
            values = values.model_dump()

        for field_name, field_value in values.items():
            if isinstance(field_value, datetime):
                if field_value.tzinfo is None or field_value.tzinfo.utcoffset(field_value) is None:
                    values[field_name] = field_value.replace(
                        tzinfo=ZoneInfo('UTC'))
            elif isinstance(field_value, str):
                # Attempt to parse string to datetime and then ensure it's timezone-aware
                try:
                    datetime_value = TypeAdapter(
                        datetime).validate_python(field_value)
                    if datetime_value.tzinfo is None or datetime_value.tzinfo.utcoffset(datetime_value) is None:
                        values[field_name] = datetime_value.replace(
                            tzinfo=ZoneInfo('UTC'))
                except ValidationError:
                    # If the string cannot be parsed to datetime, ignore the validation error
                    pass
        return values

    class Config:
        from_attributes = True
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


class SortEnum(Enum):
    ASC = 'asc'
    DESC = 'desc'

    @classmethod
    def from_str(cls, value: str):
        if value == 'asc':
            return cls.ASC
        elif value == 'desc':
            return cls.DESC
        else:
            raise ValueError(f'Invalid value: {value}')

    def __str__(self):
        return self.value

    def __repr__(self):
        return self.value


class Pagination(BaseModel):
    perPage: int = Field(10, ge=1)
    page: int = Field(1, ge=1)
    order: SortEnum = Field(SortEnum.ASC)


class GridLogicOperator(Enum):
    AND = "and"
    OR = "or"


class FilterItem(BaseModel):
    id: int = Field(
        ...,
        description="The id of the filter item. This is used to identify the filter item in the response.")
    field: str = Field(
        ..., description="The field to filter on. This should be the field name in the data source.")
    operator: str = Field(
        ..., description="The operator to use for the filter. The available operators depend on the data source.")
    value: Optional[str] = Field(
        None, description="The value for the filter. Some operators might not require a value.")


class FilterItems(BaseModel):
    items: Optional[List[FilterItem]] = Field(
        default=[], description="List of filter items.")
    logicOperator: Optional[GridLogicOperator] = Field(
        None, description="Logical operator to combine filter items. Defaults to OR.")

from pydantic import BaseModel, Field, EmailStr, validator, UUID4
from typing import List, Optional, Dict, Union
import uuid
import re
import json
from datetime import datetime
from pydantic.networks import IPvAnyAddress
from ipaddress import IPv4Address, IPv6Address
from .common import TimezoneAwareBaseModel
from app.core.db import WebhookNotifier


class TaskScheduleModel(BaseModel):
    id: Optional[uuid.UUID] = Field(None, description="ID of the schedule")
    task_id: Optional[uuid.UUID] = Field(None, description="ID of the task")
    year: Optional[Union[int, str]] = Field(None, description="4-digit year")
    month: Optional[Union[int, str]] = Field(None, description="Month (1-12)")
    day: Optional[Union[int, str]] = Field(
        None, description="Day of month (1-31)")
    week: Optional[Union[int, str]] = Field(
        None, description="ISO week (1-53)")
    day_of_week: Optional[Union[int, str]] = Field(
        None, description="Number or name of weekday (0-6 or mon,tue,wed,thu,fri,sat,sun)")
    hour: Optional[Union[int, str]] = Field(None, description="Hour (0-23)")
    minute: Optional[Union[int, str]] = Field(
        None, description="Minute (0-59)")
    second: Optional[Union[int, str]] = Field(
        None, description="Second (0-59)")
    start_date: Optional[Union[datetime, str]] = Field(
        None, description="Earliest possible date/time to trigger on (inclusive)")
    end_date: Optional[Union[datetime, str]] = Field(
        None, description="Latest possible date/time to trigger on (inclusive)")
    timezone: Optional[str] = Field(
        None, description="Time zone to use for the date/time calculations")
    jitter: Optional[int] = Field(
        None, description="Delay the job execution by jitter seconds at most")
    created_at: Optional[datetime] = Field(
        None, description="Time the schedule was created")
    modified_at: Optional[datetime] = Field(
        None, description="Time the schedule was modified")

    class Config:
        from_attributes = True
        json_encoders = {
            datetime: lambda dt: dt.isoformat(),
            uuid.UUID: lambda u: str(u)
        }
        json_schema_extra = {
            "example": {
                "year": "2021",
                "month": "1",
                "day": "1",
                "hour": "0",
                "minute": "0",
                "second": "0",
                "timezone": "UTC"
            }
        }


class JobConfig(BaseModel):
    id: str = Field(None, description="ID of the job")
    name: str = Field(..., description="Unique name of the job")
    type: Optional[str] = Field(
        default="celery", description="Type of the job")
    args: Optional[List[str]] = Field(
        default_factory=list, description="Arguments for the job")
    kwargs: Optional[Dict[str, str]] = Field(
        default_factory=dict, description="Keyword arguments for the job")
    schedule: Optional[TaskScheduleModel] = Field(
        None, description="Scheduling details for the job")

    class Config:
        from_attributes = True
        json_encoders = {
            datetime: lambda dt: dt.isoformat(),
            uuid.UUID: lambda u: str(u)
        }
        json_schema_extra = {
            "example": {
                "name": "group:name",
                "type": "celery",
                "args": ["arg1", "arg2"],
                "kwargs": {"key1": "value1", "key2": "value2"},
                "schedule": {
                    "year": "2021",
                    "month": "1",
                    "day": "1",
                    "hour": "0",
                    "minute": "0",
                    "second": "0",
                    "timezone": "UTC"
                }
            }
        }


class EmailAddressCreate(BaseModel):
    email: EmailStr = Field(..., description="Email address to notify")

    class Config:
        from_attributes = True
        json_schema_extra = {
            "example": {
                "email": "user@example.com"
            }
        }


class EmailNotifierCreate(BaseModel):
    email_addresses: List[EmailAddressCreate] = Field(
        ..., description="List of email addresses to notify")

    class Config:
        from_attributes = True
        json_schema_extra = {
            "example": {
                "email_addresses": [
                    {"email": "user1@example.com"},
                    {"email": "user2@example.com"}
                ]
            }
        }


class WebhookNotifierCreate(BaseModel):
    url: str = Field(..., description="Webhook URL")
    headers: Optional[Dict[str, str]] = Field(
        None, description="Optional headers for the webhook")

    @validator('url')
    def url_must_be_valid(cls, v):
        if not re.match(r'^(http|https)://', v):
            raise ValueError("Invalid URL format")
        return v

    class Config:
        from_attributes = True
        json_schema_extra = {
            "example": {
                "url": "https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX",
                "headers": {
                    "Authorization": "Bearer xoxb-xxxxxxxxxxxx-xxxxxxxxxxxx-xxxxxxxxxxxx"
                }
            }
        }


class NotifierCreate(BaseModel):
    name: str = Field(..., description="Name of the notifier")
    description: Optional[str] = Field(
        None, description="Description of the notifier")
    type: str = Field(..., description="Type of the notifier",
                      pattern='^(email|webhook)$')
    status: Optional[str] = Field(
        'enabled', description="Status of the notifier", pattern='^(enabled|disabled)$')
    email_notifier: Optional[EmailNotifierCreate] = Field(
        None, description="Email notifier details")
    webhook_notifier: Optional[WebhookNotifierCreate] = Field(
        None, description="Webhook notifier details")
    schedule: Optional[TaskScheduleModel] = Field(
        None, description="Scheduling details for the notifier")

    @validator('name')
    def name_must_not_contain_spaces(cls, v):
        if isinstance(v, str) and not re.match(r'^\S*$', v):
            raise ValueError("Name must not contain spaces")
        return v

    @validator('type')
    def type_must_be_valid(cls, v):
        if v not in ["email", "webhook"]:
            raise ValueError("Type must be either 'email' or 'webhook'")
        return v

    class Config:
        from_attributes = True
        json_schema_extra = {
            "example": {
                "name": "My Notifier",
                "description": "Notifier for system alerts",
                "type": "email",
                "status": "active",
                "email_notifier": {
                    "email_addresses": [
                        {"email": "user1@example.com"},
                        {"email": "user2@example.com"}
                    ]
                },
                "schedule": {
                    "year": "2021",
                    "month": "1",
                    "day": "1",
                    "hour": "0",
                    "minute": "0",
                    "second": "0",
                    "timezone": "UTC"
                }
            }
        }


class NotifierUpdate(BaseModel):
    name: Optional[str] = Field(None, description="Name of the notifier")
    description: Optional[str] = Field(
        None, description="Description of the notifier")
    status: Optional[str] = Field(
        None, description="Status of the notifier", pattern='^(enabled|disabled)$')
    schedule: Optional[TaskScheduleModel] = Field(
        None, description="Scheduling details for the notifier")

    @validator('name')
    def name_must_not_contain_spaces(cls, v):
        if v is not None and isinstance(v, str) and not re.match(r'^\S*$', v):
            raise ValueError("Name must not contain spaces")
        return v

    class Config:
        from_attributes = True
        json_schema_extra = {
            "example": {
                "name": "Updated Notifier",
                "description": "Updated description",
                "status": "disabled",
                "schedule": {
                    "year": "2021",
                    "month": "1",
                    "day": "1",
                    "hour": "0",
                    "minute": "0",
                    "second": "0",
                    "timezone": "UTC"
                }
            }
        }


class NotifierBase(BaseModel):
    id: UUID4 = Field(..., description="The ID of the notifier")
    name: str = Field(..., description="Name of the notifier")
    description: Optional[str] = Field(
        None, description="Description of the notifier")
    type: str = Field(..., description="Type of the notifier",
                      pattern='^(email|webhook)$')
    status: str = Field(..., description="Status of the notifier",
                        pattern='^(enabled|disabled)$')
    created_at: Optional[datetime] = Field(
        None, description="Time the notifier was created")
    modified_at: Optional[datetime] = Field(
        None, description="Time the notifier was modified")

    class Config:
        from_attributes = True
        json_encoders = {
            datetime: lambda dt: dt.isoformat(),
            uuid.UUID: lambda u: str(u)
        }


class EmailNotifierResponse(NotifierBase):
    email_addresses: List[EmailStr] = Field(...,
                                            description="List of email addresses to notify")

    class Config:
        from_attributes = True
        json_schema_extra = {
            "example": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "name": "Email Notifier",
                "description": "Notifier for email alerts",
                "type": "email",
                "status": "enabled",
                "created_at": "2023-05-01T12:34:56",
                "modified_at": "2023-06-01T12:34:56",
                "email_addresses": ["user1@example.com", "user2@example.com"]
            }
        }


class WebhookNotifierResponse(NotifierBase):
    url: str = Field(..., description="Webhook URL")

    class Config:
        from_attributes = True
        json_schema_extra = {
            "example": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "name": "Webhook Notifier",
                "description": "Notifier for webhook alerts",
                "type": "webhook",
                "status": "enabled",
                "created_at": "2023-05-01T12:34:56",
                "modified_at": "2023-06-01T12:34:56",
                "url": "https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX",
                "headers": {
                    "Authorization": "Bearer xoxb-xxxxxxxxxxxx-xxxxxxxxxxxx-xxxxxxxxxxxx"
                }
            }
        }


class NotifierResponse(BaseModel):
    total_records: int = Field(..., description="Total number of notifiers")
    records: List[Union[EmailNotifierResponse, WebhookNotifierResponse]] = Field(
        ..., description="List of notifiers")

    class Config:
        from_attributes = True
        json_schema_extra = {
            "example": {
                "total_records": 2,
                "records": [
                    {
                        "id": "123e4567-e89b-12d3-a456-426614174000",
                        "name": "Email Notifier",
                        "description": "Notifier for email alerts",
                        "type": "email",
                        "status": "enabled",
                        "created_at": "2023-05-01T12:34:56",
                        "modified_at": "2023-06-01T12:34:56",
                        "email_addresses": ["user1@example.com", "user2@example.com"]
                    },
                    {
                        "id": "123e4567-e89b-12d3-a456-426614174001",
                        "name": "Webhook Notifier",
                        "description": "Notifier for webhook alerts",
                        "type": "webhook",
                        "status": "enabled",
                        "created_at": "2023-05-01T12:34:56",
                        "modified_at": "2023-06-01T12:34:56",
                        "url": "https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX",
                        "headers": {
                            "Authorization": "Bearer xoxb-xxxxxxxxxxxx-xxxxxxxxxxxx-xxxxxxxxxxxx"
                        }
                    }
                ]
            }
        }


class TaskPrompt(BaseModel):
    prompt: str = Field(..., description="The name of the prompt")
    default_value: Optional[str] = Field(None,
                                         description="The default value for the prompt")
    value: Optional[str] = Field(None, description="The value of the prompt")


class TaskConfig(BaseModel):
    name: str = Field(..., description="Unique name of the task")
    status: str = Field(...,
                        description="Status of the task, e.g., 'enabled'",
                        pattern='^(enabled|disabled|0|1)$')
    type: str = Field('celery', description="Type of the task",
                      pattern='^(fabric|invoke|script|ansible|celery)$')
    owner: str = Field(..., description="Owner of the task")
    organization: str = Field(..., description="Organization owning the task")
    description: Optional[str] = Field(
        None, description="Description of the task")
    schedule: Optional[TaskScheduleModel] = Field(
        None, description="Scheduling details for the task")
    args: Optional[List[str]] = Field(
        default_factory=list, description="Arguments for the task")
    kwargs: Optional[Dict[str, str]] = Field(
        default_factory=dict, description="Keyword arguments for the task")
    metadata: Optional[Dict[str, str]] = Field(
        default_factory=dict, description="Metadata for the task")
    prompts: Optional[List[TaskPrompt]] = Field(
        default_factory=list, description="Prompts for the task")
    environments: Optional[List[str]] = Field(
        default_factory=list, description="Environment where the task will run")
    components: Optional[List[str]] = Field(
        default_factory=list, description="Components where the task will run")
    datacenter: Optional[str] = Field(
        None, description="Datacenter where the task will run")
    hosts: List[IPvAnyAddress] = Field(default_factory=list,
                                       description="Hosts where the task will run")
    promptForCredentials: Optional[bool] = Field(
        False, description="Whether the user should be prompted for credentials")
    promptForAPIKey: Optional[bool] = Field(
        False, description="Whether the user should be prompted for an API key")

    @validator('status', pre=True)
    def convert_status(cls, v):
        if v == "0":
            return "disabled"
        elif v == "1":
            return "enabled"
        return v

    @validator('datacenter', pre=True, each_item=False)
    def check_for_spaces_in_datacenter(cls, v):
        if isinstance(v, str) and not re.match(r'^\S*$', v):
            raise ValueError("Field must not contain spaces")
        return v

    @validator('environments', 'components', pre=True, each_item=True)
    def check_for_spaces_in_lists(cls, v):
        if isinstance(v, str) and not re.match(r'^\S*$', v):
            raise ValueError("List item must not contain spaces")
        return v

    class Config:
        from_attributes = True
        json_encoders = {
            datetime: lambda dt: dt.isoformat() if isinstance(dt, datetime) else dt,
            uuid.UUID: lambda u: str(u),
            IPv4Address: lambda ip: str(ip),
            IPv6Address: lambda ip: str(ip)
        }
        json_schema_extra = {
            "example": {
                "name": "task:user_info",
                "status": "enabled",
                "type": "celery",
                "owner": "admin",
                "organization": "org1",
                "description": "Get user information",
                "schedule": {
                    "year": "2021",
                    "month": "1",
                    "day": "1",
                    "hour": "0",
                    "minute": "0",
                    "second": "0",
                    "timezone": "UTC"
                },
                "args": ["arg1", "arg2"],
                "kwargs": {"key": "value"},
                "metadata": {"key": "value"},
                "prompts": [{"name": "prompt1", "default_value": "value1"}],
                "environments": ["env1", "env2"],
                "components": ["comp1", "comp2"],
                "datacenter": "dc1",
                "hosts": ["10.10.0.1"],
                "promptForCredentials": False,
                "promptForAPIKey": False
            }
        }


class TaskModel(TimezoneAwareBaseModel):
    id: Optional[uuid.UUID] = Field(None, description="ID of the task")
    name: str = Field(..., description="Unique name of the task")
    celery_job_name: Optional[str] = Field(
        None, description="Name of the Celery job")
    type: str = Field(..., description="Type of the task")
    status: str = Field(..., description="Status of the task")
    owner: str = Field(..., description="Owner of the task")
    organization: str = Field(..., description="Organization of the task")
    next_run_time: Optional[datetime] = Field(
        None, description="Next time the task will run")
    description: Optional[str] = Field(
        None, description="Description of the task")
    schedule: Optional[TaskScheduleModel] = Field(
        None, description="Schedule for the task")
    args: Optional[List[str]] = Field(
        None, description="Arguments for the task")
    kwargs: Optional[Dict[str, str]] = Field(
        None, description="Keyword arguments for the task")
    metadata: Optional[Dict[str, str]] = Field(
        None, description="Metadata for the task")
    prompts: Optional[List[TaskPrompt]] = Field(
        None, description="Prompts for the task")
    hosts: List[str] = Field(..., description="Hosts where the task will run")
    created_at: Optional[datetime] = Field(
        None, description="Time the task was created")
    modified_at: Optional[datetime] = Field(
        None, description="Time the task was modified")

    @validator('status')
    def status_must_be_known(cls, v):
        if v not in ["enabled", "disabled"]:
            raise ValueError("status must be either 'enabled' or 'disabled'")
        return v

    class Config:
        from_attributes = True
        json_encoders = {
            datetime: lambda dt: dt.isoformat(),
            uuid.UUID: lambda u: str(u)
        }

import time
import asyncio
import logging
import logging.config
import yaml
import ssl
from datetime import datetime
from fastapi import FastAPI, APIRouter, Request, Response, Depends
from fastapi.middleware.cors import CORSMiddleware
from asgi_correlation_id import CorrelationIdMiddleware
from core.db import create_db_and_tables
from core.security import generate_api_key
from core.settings import Settings
from core.session import RedisClientSingleton
from core.logger import LoggerSetup
from core.auth import validate_api_key
from pathlib import Path
from prometheus_fastapi_instrumentator import Instrumentator
from functools import lru_cache

from fastapi_events.dispatcher import dispatch
from fastapi_events.middleware import EventHandlerASGIMiddleware
from fastapi_events.handlers.local import local_handler

from app.routers import notifier
from contextlib import asynccontextmanager

from .utils import read_api_key_from_file, format_uptime

from fastapi_cache import FastAPICache
from fastapi_cache.backends.redis import RedisBackend


@lru_cache
def get_settings():
    return Settings()


logger_setup = LoggerSetup()

# Global variable to store the start time
app_start_time = datetime.now()


def create_app(lifespan=None) -> FastAPI:
    app = FastAPI(
        title="OSCAR Notifier Middleware API",
        description="API for OSCAR Notifier Middleware",
        version="0.1.0",
        lifespan=lifespan,
    )

    # Configure SSL Context
    # Configure SSL Context
    ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ssl_context.load_cert_chain(
        certfile=get_settings().NOTIFIER_SSL_CERT, keyfile=get_settings().NOTIFIER_SSL_KEY)  # type: ignore

    # Add Prometheus metrics
    Instrumentator().instrument(app).expose(app)

    # Create a main router
    main_router = APIRouter(
        prefix="/api", dependencies=[Depends(validate_api_key)])

    main_router.include_router(notifier.router)
    main_router.include_router(notifier.router, prefix="/v1")
    main_router.include_router(notifier.router, prefix="/latest")

    # Include the main router in the app
    app.include_router(main_router)

    return app

# define lifespan events to initialize logger queue


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger_setup.setup_logging()
    await create_db_and_tables()

    global app_start_time  # Reference the global variable
    app_start_time = datetime.now()  # Record the start time when the app starts

    yield
    listener = logger_setup.get_queue_listener()
    if listener:
        listener.stop()

app = create_app(lifespan=lifespan)


@app.middleware("http")
async def log_execution_time(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(round(process_time, 2))
    return response

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=get_settings().ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH"],
    allow_headers=[
        "X-Request-ID",
        "X-Requested-With",
        "Content-Type",
        "Accept",
        "Origin",
        "Authorization",
        "Access-Control-Allow-Origin",
        "Access-Control-Allow-Headers",
        "Access-Control-Allow-Methods",
        "Access-Control-Allow-Credentials",
        "X-Process-Time",
        "X-Correlation-ID",
        "X-CoreAPI-Cache",
        "X-API-Key"
    ],
    expose_headers=[
        "X-Request-ID",
        "X-Process-Time",
        "X-Correlation-ID",
        "X-CoreAPI-Cache",
    ],
)

# Add correlation ID middleware
app.add_middleware(CorrelationIdMiddleware, header_name="X-Correlation-ID")


# Add Dispatching middleware
app.add_middleware(
    EventHandlerASGIMiddleware,
    handlers=[local_handler],
)


@app.get("/health")
async def ping():
    version = get_settings().PROJECT_VERSION
    service = get_settings().PROJECT_NAME
    current_time = datetime.now()
    uptime = current_time - app_start_time  # Calculate uptime
    uptime_seconds = int(uptime.total_seconds())
    formatted_uptime = format_uptime(uptime_seconds)

    return {
        "status": "up",
        "version": version,
        "service": service,
        "uptime_seconds": uptime_seconds,
        "formatted_uptime": formatted_uptime
    }

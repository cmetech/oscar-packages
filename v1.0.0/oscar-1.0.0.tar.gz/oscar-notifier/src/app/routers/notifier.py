from datetime import datetime, timedelta
import logging
import json
import uuid
from pydantic import ValidationError
from typing import List, Optional, Annotated, Union
from fastapi import APIRouter, HTTPException, Depends, Body, Path, Query, status
from httpx import AsyncClient
from app.schemas.notifier import NotifierCreate, NotifierUpdate, NotifierResponse
from app.schemas.common import Pagination, SortEnum, FilterItems, GridLogicOperator
from app.core.settings import Settings
from sqlalchemy.ext.asyncio import AsyncSession
from app.utils import pagination_params
from app.core.db import get_async_session
from app.core.notifier_manager import NotifierManagerService

router = APIRouter(prefix="/notifiers", tags=["notifiers"])

settings = Settings()

logger = logging.getLogger('oscar-notifier')


@router.get("",
            summary="Retrieve all notifiers",
            response_model=NotifierResponse,
            status_code=status.HTTP_200_OK)
async def get_notifiers(
        pagination: Annotated[Pagination, Depends(pagination_params)],
        column: Optional[str] = Query(
            "name", description="The column to sort by"),
        filter: Optional[str] = Query(None, description="The filter to apply"),
        db: AsyncSession = Depends(get_async_session)):

    if filter:
        try:
            filter_criteria = json.loads(filter)
            filter_items = FilterItems(**filter_criteria)
        except (json.JSONDecodeError, ValidationError) as e:
            raise HTTPException(
                status_code=400, detail=f"Invalid filter format: {str(e)}")
    else:
        logger.debug("No filter items provided")
        filter_items = None

    notifier_manager = await NotifierManagerService.get_instance(db)
    notifiers = await notifier_manager.get_notifiers(
        pagination=pagination,
        column=column or "name",
        filter=filter_items
    )

    return notifiers


@router.post("",
             summary="Add a new notifier",
             response_model=NotifierCreate,
             status_code=status.HTTP_201_CREATED)
async def add_notifier(
        notifier: NotifierCreate = Body(...,
                                        description="The notifier to add"),
        db: AsyncSession = Depends(get_async_session)):

    try:
        notifier_manager = await NotifierManagerService.get_instance(db)
        new_notifier = await notifier_manager.add_notifier(notifier)

        if new_notifier:
            logger.debug(f"[Register Notifier]: added {new_notifier}")

        return new_notifier
    except ValidationError as e:
        logger.error(f"Validation error: {e}")
        raise HTTPException(
            status_code=422,
            detail=f"Failed to validate response model: {str(e)}"
        )
    except ValueError as e:
        logger.error(f"Type conversion error: {e}")
        raise HTTPException(
            status_code=500,
            detail="Internal server error in type conversion for response data."
        )


@router.put("/{id}",
            summary="Update a notifier",
            response_model=NotifierCreate,
            status_code=status.HTTP_200_OK)
async def update_notifier(
        id: str = Path(..., description="The ID of the notifier to update"),
        notifier: NotifierUpdate = Body(...,
                                        description="The updated notifier"),
        db: AsyncSession = Depends(get_async_session)):

    notifier_manager = await NotifierManagerService.get_instance(db)
    updated_notifier = await notifier_manager.update_notifier(id, notifier)

    if updated_notifier is None:
        raise HTTPException(
            status_code=404, detail="Notifier not found or update failed")
    return updated_notifier


@router.delete("/{id}",
               summary="Delete a notifier",
               status_code=status.HTTP_204_NO_CONTENT)
async def delete_notifier(
        id: uuid.UUID = Path(...,
                             description="The ID of the notifier to delete"),
        db: AsyncSession = Depends(get_async_session)):

    notifier_manager = await NotifierManagerService.get_instance(db)
    await notifier_manager.delete_notifier(str(id))

    return None


@router.post("/disable", summary="Disable notifiers")
async def disable_notifiers(notifier_ids: List[str] = Body(...), db: AsyncSession = Depends(get_async_session)):
    notifier_manager = await NotifierManagerService.get_instance(db)
    # type: ignore
    update_notifiers = await notifier_manager.disable_notifiers(notifier_ids)

    return {
        "message": "Notifiers have been disabled",
        "notifier_ids": update_notifiers
    }


@router.post("/enable", summary="Enable notifiers")
async def enable_notifiers(notifier_ids: List[str] = Body(...), db: AsyncSession = Depends(get_async_session)):
    notifier_manager = await NotifierManagerService.get_instance(db)
    # type: ignore
    update_notifiers = await notifier_manager.enable_notifiers(notifier_ids)

    return {
        "message": "Notifiers have been enabled",
        "notifier_ids": update_notifiers
    }

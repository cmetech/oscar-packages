import os
import uuid
import logging
from typing import AsyncGenerator, Generator, List, Dict, Any, Union, Optional

from fastapi import Depends
from fastapi_users.db import SQLAlchemyBaseUserTableUUID, SQLAlchemyUserDatabase
from sqlalchemy import func, ForeignKey, Enum, JSON, FLOAT, Column, Text
from sqlalchemy.sql import Select
from sqlalchemy import DateTime, String, Integer, create_engine, or_, and_
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import Session, DeclarativeBase, Mapped, mapped_column, class_mapper
from sqlalchemy.orm import relationship, validates, sessionmaker, scoped_session, Query
from sqlalchemy.dialects.mysql import TIMESTAMP, VARCHAR, CHAR, dialect
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.schema import UniqueConstraint
from sqlalchemy.inspection import inspect
from app.schemas.common import FilterItems

from contextlib import contextmanager, asynccontextmanager

from datetime import datetime
from app.core.settings import Settings


logger = logging.getLogger('oscar-metricstore')
settings = Settings()


class Base(DeclarativeBase):
    pass


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(
        TIMESTAMP, nullable=True, server_default=func.now()
    )
    modified_at: Mapped[datetime] = mapped_column(
        TIMESTAMP,
        nullable=True,
        server_default=func.now(),
        onupdate=func.now(),
    )


class Notifier(Base, TimestampMixin):
    __tablename__ = "NTF_Notifiers"

    id: Mapped[uuid.UUID] = mapped_column(
        CHAR(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name: Mapped[str] = mapped_column(VARCHAR(255), nullable=False)
    description: Mapped[str] = mapped_column(VARCHAR(255), nullable=True)
    type: Mapped[str] = mapped_column(VARCHAR(25), nullable=False)
    status: Mapped[str] = mapped_column(
        VARCHAR(25), nullable=False, default='active')

    # Relationships
    email_notifier = relationship(
        "EmailNotifier", back_populates="notifier", cascade="all, delete-orphan", uselist=False)
    webhook_notifier = relationship(
        "WebhookNotifier", back_populates="notifier", cascade="all, delete-orphan", uselist=False)


class EmailNotifier(Base):
    __tablename__ = "NTF_Email_Notifiers"

    id: Mapped[uuid.UUID] = mapped_column(
        CHAR(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    notifier_id: Mapped[uuid.UUID] = mapped_column(
        CHAR(36), ForeignKey('NTF_Notifiers.id'))

    # Relationship back to Notifier
    notifier = relationship("Notifier", back_populates="email_notifier")

    # Relationship to EmailAddresses
    email_addresses = relationship(
        "EmailAddress", back_populates="email_notifier", cascade="all, delete-orphan")


class EmailAddress(Base):
    __tablename__ = "NTF_Email_Addresses"

    id: Mapped[uuid.UUID] = mapped_column(
        CHAR(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    email_notifier_id: Mapped[uuid.UUID] = mapped_column(
        CHAR(36), ForeignKey('NTF_Email_Notifiers.id'))
    email: Mapped[str] = mapped_column(VARCHAR(255), nullable=False)

    # Relationship back to EmailNotifier
    email_notifier = relationship(
        "EmailNotifier", back_populates="email_addresses")


class WebhookNotifier(Base):
    __tablename__ = "NTF_Webhook_Notifiers"

    id: Mapped[uuid.UUID] = mapped_column(
        CHAR(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    notifier_id: Mapped[uuid.UUID] = mapped_column(
        CHAR(36), ForeignKey('NTF_Notifiers.id'))
    url: Mapped[str] = mapped_column(VARCHAR(255), nullable=False)

    # Relationship back to Notifier
    notifier = relationship("Notifier", back_populates="webhook_notifier")


# Task Tables used for API probes
class Task(Base, TimestampMixin):
    __tablename__ = 'TM_Tasks'

    id: Mapped[uuid.UUID] = mapped_column(
        CHAR(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name: Mapped[str] = mapped_column(String(255), nullable=False, unique=True)
    celery_job_name: Mapped[str] = mapped_column(
        String(255), nullable=False, unique=True)
    type: Mapped[str] = mapped_column(String(25), nullable=False)
    status: Mapped[str] = mapped_column(String(25), nullable=False)
    owner: Mapped[str] = mapped_column(String(50), nullable=False)
    organization: Mapped[str] = mapped_column(String(50), nullable=True)
    description: Mapped[str] = mapped_column(String(255), nullable=True)

    # Relationships
    history = relationship(
        "TaskHistory", back_populates="task", cascade="all, delete-orphan")
    schedule = relationship(
        "TaskSchedule", back_populates="task", uselist=False, cascade="all, delete-orphan")
    task_metadata = relationship(
        "TaskMetadata", back_populates="task", cascade="all, delete-orphan")  # type: ignore
    targets = relationship(
        "TaskTargets", back_populates="task", cascade="all, delete-orphan")
    args = relationship("TaskArgs", back_populates="task",
                        cascade="all, delete-orphan")
    kwargs = relationship("TaskKwargs", back_populates="task",
                          cascade="all, delete-orphan")
    prompts = relationship("TaskPrompts", back_populates="task",
                           cascade="all, delete-orphan")


class TaskPrompts(Base, TimestampMixin):
    __tablename__ = 'TM_Prompts'

    id: Mapped[uuid.UUID] = mapped_column(
        CHAR(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    task_id: Mapped[uuid.UUID] = mapped_column(
        CHAR(36), ForeignKey('TM_Tasks.id'))
    prompt: Mapped[str] = mapped_column(String(255), nullable=False)
    sequence: Mapped[int] = mapped_column(Integer, nullable=False)
    default_value: Mapped[str] = mapped_column(String(255), nullable=True)

    # Relationship back to Task
    task = relationship("Task", back_populates="prompts")

    # Composite unique constraint to ensure uniqueness of sequence per task
    __table_args__ = (
        UniqueConstraint('task_id', 'sequence',
                         name='task_prompt_sequence_uc'),
    )


class TaskArgs(Base, TimestampMixin):
    __tablename__ = 'TM_Args'

    id: Mapped[uuid.UUID] = mapped_column(
        CHAR(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    task_id: Mapped[uuid.UUID] = mapped_column(
        CHAR(36), ForeignKey('TM_Tasks.id'))
    value: Mapped[str] = mapped_column(String(255), nullable=False)
    sequence: Mapped[int] = mapped_column(Integer, nullable=False)

    # Relationship back to Task
    task = relationship("Task", back_populates="args")

    # Composite unique constraint to ensure uniqueness of sequence per task
    __table_args__ = (
        UniqueConstraint('task_id', 'sequence', name='task_arg_sequence_uc'),
    )


class TaskKwargs(Base, TimestampMixin):
    __tablename__ = 'TM_Kwargs'

    id: Mapped[uuid.UUID] = mapped_column(
        CHAR(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    task_id: Mapped[uuid.UUID] = mapped_column(
        CHAR(36), ForeignKey('TM_Tasks.id'))
    key: Mapped[str] = mapped_column(String(255), nullable=False)
    value: Mapped[str] = mapped_column(String(255), nullable=False)

    # Relationship back to Task
    task = relationship("Task", back_populates="kwargs")

    # Composite unique constraint to ensure the key is unique per task_id
    __table_args__ = (
        UniqueConstraint('task_id', 'key', name='task_kwarg_key_uc'),
    )


class TaskMetadata(Base, TimestampMixin):
    __tablename__ = 'TM_Metadata'

    id: Mapped[uuid.UUID] = mapped_column(
        CHAR(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    task_id: Mapped[uuid.UUID] = mapped_column(
        CHAR(36), ForeignKey('TM_Tasks.id'))
    key: Mapped[str] = mapped_column(String(255), nullable=False)
    value: Mapped[str] = mapped_column(Text, nullable=False)

    # Relationship back to Task
    task = relationship("Task", back_populates="task_metadata")

    # Composite unique constraint to ensure the key is unique per task_id
    __table_args__ = (
        UniqueConstraint('task_id', 'key', name='task_metadata_key_uc'),
    )


class TaskTargets(Base, TimestampMixin):
    __tablename__ = 'TM_Targets'

    id: Mapped[uuid.UUID] = mapped_column(
        CHAR(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    task_id: Mapped[uuid.UUID] = mapped_column(
        CHAR(36), ForeignKey('TM_Tasks.id'))
    host: Mapped[str] = mapped_column(String(255), nullable=False)

    # Relationship back to Task
    task = relationship("Task", back_populates="targets")

    # Composite unique constraint to ensure the key is unique per task_id
    __table_args__ = (
        UniqueConstraint('task_id', 'host', name='task_target_host_uc'),
    )


class TaskSchedule(Base, TimestampMixin):
    __tablename__ = 'TM_Schedules'

    id: Mapped[uuid.UUID] = mapped_column(
        CHAR(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    task_id: Mapped[uuid.UUID] = mapped_column(
        CHAR(36), ForeignKey('TM_Tasks.id'))
    year: Mapped[str] = mapped_column(String(10), nullable=True)
    month: Mapped[str] = mapped_column(String(10), nullable=True)
    day: Mapped[str] = mapped_column(String(10), nullable=True)
    week: Mapped[str] = mapped_column(String(10), nullable=True)
    day_of_week: Mapped[str] = mapped_column(String(10), nullable=True)
    hour: Mapped[str] = mapped_column(String(10), nullable=True)
    minute: Mapped[str] = mapped_column(String(10), nullable=True)
    second: Mapped[str] = mapped_column(String(10), nullable=True)
    start_date: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    end_date: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    timezone: Mapped[str] = mapped_column(String(255), nullable=True)
    jitter: Mapped[int] = mapped_column(Integer, nullable=True)

    # Relationship back to Task
    task = relationship("Task", back_populates="schedule")


class TaskHistory(Base, TimestampMixin):
    __tablename__ = 'TM_History'

    # Use CHAR(36) for UUID fields to store them as strings
    id: Mapped[uuid.UUID] = mapped_column(
        CHAR(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    task_id: Mapped[uuid.UUID] = mapped_column(
        CHAR(36), ForeignKey('TM_Tasks.id'))
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    state: Mapped[str] = mapped_column(String(255), nullable=False)
    alias: Mapped[str] = mapped_column(String(255), nullable=True)
    received: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    sent: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    started: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    succeeded: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    kwargs: Mapped[str] = mapped_column(
        String(255), nullable=True)  # JSON encoded string
    args: Mapped[str] = mapped_column(
        String(255), nullable=True)  # JSON encoded string
    result: Mapped[str] = mapped_column(Text, nullable=True)
    worker: Mapped[str] = mapped_column(String(255), nullable=True)
    runtime: Mapped[float] = mapped_column(FLOAT, nullable=True)
    root_id: Mapped[uuid.UUID] = mapped_column(CHAR(36), nullable=True)
    routing_key: Mapped[str] = mapped_column(String(255), nullable=True)

    # Relationship
    task = relationship("Task", back_populates="history")
    stage_history = relationship(
        "TaskStageHistory", back_populates="task_history", cascade="all, delete-orphan")


class TaskStageHistory(Base, TimestampMixin):
    __tablename__ = 'TM_StageHistory'

    id: Mapped[uuid.UUID] = mapped_column(
        CHAR(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    task_history_id: Mapped[uuid.UUID] = mapped_column(
        CHAR(36), ForeignKey('TM_History.id'))
    task_stage: Mapped[int] = mapped_column(Integer, nullable=False)
    stage_name: Mapped[str] = mapped_column(String(255), nullable=False)

    # Relationship
    task_history = relationship("TaskHistory", back_populates="stage_history")


engine = create_async_engine(
    settings.ASYNC_DATABASE_URL,
    echo=settings.NOTIFIER_DB_LOG_STATEMENTS,
    echo_pool=settings.NOTIFIER_DB_LOG_CONNECTIONS,
    pool_pre_ping=settings.NOTIFIER_DB_CHECK_CONNECTIONS,
    logging_name="oscar-notifier-engine")

async_session_maker = async_sessionmaker(
    engine, expire_on_commit=False, class_=AsyncSession)


async def create_db_and_tables():
    try:
        async with engine.begin() as conn:
            # Exclude specific tables from being created
            tables_to_exclude = [Task.__table__, TaskPrompts.__table__, TaskArgs.__table__,
                                 TaskKwargs.__table__, TaskMetadata.__table__, TaskTargets.__table__,
                                 TaskSchedule.__table__, TaskHistory.__table__, TaskStageHistory.__table__]

            # Collect all tables to be created, excluding the specified ones
            all_tables = Base.metadata.tables.values()
            tables_to_create = [
                table for table in all_tables if table not in tables_to_exclude]

            for table in tables_to_create:
                table_name = table.name

                # Check if the table exists
                table_exists = await conn.run_sync(
                    lambda conn: conn.dialect.has_table(conn, table_name)
                )

                if not table_exists:
                    await conn.run_sync(table.create)
    except SQLAlchemyError as e:
        print(f"An error occurred: {e}")


async def get_async_session() -> AsyncGenerator[AsyncSession, None]:
    async with async_session_maker() as session:
        yield session

sync_engine = create_engine(
    settings.SYNC_DATABASE_URL,
    echo=settings.NOTIFIER_DB_LOG_STATEMENTS,
    echo_pool=settings.NOTIFIER_DB_LOG_CONNECTIONS,
    pool_pre_ping=settings.NOTIFIER_DB_CHECK_CONNECTIONS,
    logging_name="oscar-notifier-engine",
)  # type: ignore


session_factory = sessionmaker(
    autocommit=False, autoflush=False, bind=sync_engine)
SessionLocal = scoped_session(session_factory)


def get_db_session() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@contextmanager
def get_transaction(session):
    """Provide a transactional scope around a series of operations."""
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


@asynccontextmanager
async def get_async_transaction():
    """Provide a transactional scope around a series of operations."""
    async with async_session_maker() as session:
        async with session.begin():
            try:
                yield session
            except Exception as e:
                await session.rollback()
                raise
            else:
                await session.commit()


# Filtering functions
def find_class_for_field(model_classes: List[Any], field_name: str) -> Union[Base, None]:
    """
    Given a list of SQLAlchemy model classes and a field name,
    return the class that contains the given field, if any.
    This function now also considers relationships.
    """
    for model_class in model_classes:
        if hasattr(model_class, field_name):  # Direct attribute
            logger.debug("['FilterQuery'] Found class %s for field: %s",
                         model_class.__name__, field_name)
            return model_class

        # Inspect model for relationships
        insp = inspect(model_class)

        if insp and insp.mapper:
            mapper = insp.mapper
            for rel in mapper.relationships:
                if hasattr(rel.mapper.entity, field_name):
                    logger.debug("['FilterQuery'] Found related class %s for field: %s through relationship",
                                 rel.mapper.entity.__name__, field_name)
                    return rel.mapper.entity

    logger.debug("['FilterQuery'] No class found for field: %s", field_name)
    return None


def construct_filter_condition(field_name: Any, operator: str, value: Any, model_class: Optional[Base] = None) -> Any:
    """
    Construct the filter condition based on the operator.
    """

    field = None
    if model_class is None:
        field = field_name
    else:
        logger.debug("['FilterQuery'] Constructing filter condition for class: %s, field: %s, operator: %s, value: %s",
                     model_class.__name__, field_name, operator, value)
        field = getattr(model_class, field_name)

    # Mapping the operator strings to SQLAlchemy filter expressions
    if operator == "contains":
        return field.contains(value)
    elif operator == "equals" or operator == "=":
        return field == value
    elif operator == "startsWith":
        return field.like(value + '%')
    elif operator == "endsWith":
        return field.like('%' + value)
    elif operator == "isEmpty":
        return field == None  # noqa: E711
    elif operator == "!=":
        return field != value
    elif operator == ">":
        return field > value
    elif operator == "<":
        return field < value
    elif operator == "<=":
        return field <= value
    elif operator == ">=":
        return field >= value
    else:
        raise ValueError(f"Unsupported operator: {operator}")


def apply_filter_rule(result: Any, field_name: str, operator: str, value: Any) -> bool:
    """
    Applies a single filter rule to a result object and returns True if the result passes the filter.
    This is adapted from construct_filter_condition but for in-memory comparison.
    """
    actual_value = getattr(result, field_name, None)

    # Implement comparison based on the operator
    if operator == "contains":
        return value in actual_value if actual_value is not None else False
    elif operator == "equals" or operator == "=":
        return actual_value == value
    elif operator == "startsWith":
        return actual_value.startswith(value) if isinstance(actual_value, str) else False
    elif operator == "endsWith":
        return actual_value.endswith(value) if isinstance(actual_value, str) else False
    elif operator == "isEmpty":
        return actual_value is None
    elif operator == "!=":
        return actual_value != value
    elif operator == ">":
        return actual_value > value
    elif operator == "<":
        return actual_value < value
    elif operator == "<=":
        return actual_value <= value
    elif operator == ">=":
        return actual_value >= value
    else:
        logger.error(f"Unsupported operator: {operator}")
        return False


def apply_filters_to_query(
        base_query: Query,
        filter_model: FilterItems,
        model_classes: Optional[List[Any]] = None,
        column_aliases: Optional[Dict[str, Column[Any]]] = None) -> Query:
    """
    Dynamically build filters based on the filter_model and apply them to the base_query.
    The logical operator (AND/OR) is only applied when there are multiple filter rules.
    """
    logger.debug("['FilterQuery'] Applying filters to query with logic operator: %s",
                 filter_model.logicOperator)

    # Return the base query immediately if no filter items are provided
    if not filter_model.items:
        logger.debug(
            "['FilterQuery'] No filter items provided, returning base query")
        return base_query

    conditions = []
    for item in filter_model.items:
        field_name = item.field
        operator = item.operator
        value = item.value

        logger.debug("['FilterQuery'] Processing filter item: field=%s, operator=%s, value=%s",
                     field_name, operator, value)

        # Skip fields starting with - derived_
        if field_name.startswith("derived_") or field_name.startswith("ignore_"):
            logger.debug(
                "['FilterQuery'] Skipping derived field: %s", field_name)
            continue

        # Check if the field is an alias
        if column_aliases:
            if field_name in column_aliases:
                field_name = column_aliases[field_name]
                condition = construct_filter_condition(
                    field_name, item.operator, item.value)
                conditions.append(condition)
            else:
                logger.error(
                    "['FilterQuery'] Field %s not found in the provided column aliases.", field_name)
                continue

        else:
            # Check if the field is present in the provided model classes
            if model_classes:
                model_class = find_class_for_field(model_classes, field_name)
                if model_class is None:
                    logger.error(
                        "['FilterQuery'] Field %s not found in the provided model classes.", field_name)
                    continue

                # Construct the condition and add it to the list
                condition = construct_filter_condition(
                    field_name, operator, value, model_class)
                conditions.append(condition)

    # Apply conditions directly if there's only one, else use the specified logical operator
    if len(conditions) == 1:
        base_query = base_query.filter(conditions[0])
    elif filter_model.logicOperator == 'or':
        base_query = base_query.filter(or_(*conditions))
    else:  # Apply 'and' operator by default if there are multiple conditions
        base_query = base_query.filter(and_(*conditions))

    logger.debug("['FilterQuery'] Filters applied to query")

    # Convert the final query to a string and log it
    query_str = str(base_query.statement.compile(
        compile_kwargs={"literal_binds": True}))
    logger.debug(f"['FilterQuery'] Final SQL Query: {query_str}")

    return base_query


def apply_filters_to_select(
        base_query: Select,
        filter_model: FilterItems,
        model_classes: Optional[List[Any]] = None,
        column_aliases: Optional[Dict[str, Column[Any]]] = None) -> Select:
    """
    Dynamically build filters based on the filter_model and apply them to the base_query.
    The logical operator (AND/OR) is only applied when there are multiple filter rules.
    """
    logger.debug("['FilterQuery'] Applying filters to query with logic operator: %s",
                 filter_model.logicOperator)

    # Return the base query immediately if no filter items are provided
    if not filter_model.items:
        logger.debug(
            "['FilterQuery'] No filter items provided, returning base query")
        return base_query

    conditions = []
    for item in filter_model.items:
        field_name = item.field
        operator = item.operator
        value = item.value

        logger.debug("['FilterQuery'] Processing filter item: field=%s, operator=%s, value=%s",
                     field_name, operator, value)

        # Skip fields starting with - derived_
        if field_name.startswith("derived_") or field_name.startswith("ignore_"):
            logger.debug(
                "['FilterQuery'] Skipping derived field: %s", field_name)
            continue

        # Check if the field is an alias
        if column_aliases:
            if field_name in column_aliases:
                field_name = column_aliases[field_name]
                condition = construct_filter_condition(
                    field_name, item.operator, item.value)
                conditions.append(condition)
            else:
                logger.error(
                    "['FilterQuery'] Field %s not found in the provided column aliases.", field_name)
                continue

        else:
            # Check if the field is present in the provided model classes
            if model_classes:
                model_class = find_class_for_field(model_classes, field_name)
                if model_class is None:
                    logger.error(
                        "['FilterQuery'] Field %s not found in the provided model classes.", field_name)
                    continue

                # Construct the condition and add it to the list
                condition = construct_filter_condition(
                    field_name, operator, value, model_class)
                conditions.append(condition)

    # Apply conditions directly if there's only one, else use the specified logical operator
    if len(conditions) == 1:
        base_query = base_query.filter(conditions[0])
    elif filter_model.logicOperator == 'or':
        base_query = base_query.filter(or_(*conditions))
    else:  # Apply 'and' operator by default if there are multiple conditions
        base_query = base_query.filter(and_(*conditions))

    logger.debug("['FilterQuery'] Filters applied to query")

    # Convert the final query to a string and log it
    if isinstance(base_query, Select):
        query_str = str(base_query.compile(
            compile_kwargs={"literal_binds": True}, dialect=dialect()))
    else:
        # Fallback for any other type that is not a Select object
        query_str = str(base_query)

    logger.debug(f"['FilterQuery'] Final SQL Query: {query_str}")

    return base_query


def apply_filters_to_results(results: List[Any], filter_model: FilterItems):
    if not filter_model.items:
        logger.debug(
            "['FilterQuery'] No filter items provided, returning results")
        return results

    filtered_results = []

    for result in results:
        passed_filters = False if filter_model.logicOperator == 'or' else True

        for item in filter_model.items:
            # Process only fields that start with 'derived_'
            if not item.field.startswith("derived_"):
                continue

            # Strip the 'derived_' prefix
            field_name = item.field[8:]

            filter_passes = apply_filter_rule(
                result, field_name, item.operator, item.value)

            if filter_model.logicOperator == 'or' and filter_passes:
                # For 'or' logic, passing any filter is enough
                passed_filters = True
                break  # No need to check further filters
            elif filter_model.logicOperator == 'and' and not filter_passes:
                # For 'and' logic, failing any filter disqualifies the result
                passed_filters = False
                break  # No need to check further filters

        if passed_filters:
            filtered_results.append(result)

    return filtered_results

import os
from pydantic_settings import BaseSettings
import ssl


class Settings(BaseSettings):
    PROJECT_NAME: str = os.environ.get("SERVICE_NAME", "Notifier Service")
    PROJECT_DESCRIPTION: str = "API for OSCAR Middleware"
    PROJECT_VERSION: str = os.environ.get("VERSION", "1.0.0")

    SENDGRID_APIKEY: str = os.environ.get("SENDGRID_APIKEY", "")

    ASYNC_DATABASE_URL: str = os.environ.get(
        "ASYNC_DB_URL", "mysql+aiomysql://oscar:oscar@127.0.0.1:3306/oscar?charset=utf8mb4"
    )

    SYNC_DATABASE_URL: str = os.environ.get(
        "SYNC_DB_URL", "mysql+mysqldb://oscar:oscar@127.0.0.1:3306/oscar?charset=utf8mb4"
    )

    NOTIFIER_APIKEY_NAME: str = os.environ.get(
        "NOTIFIER_APIKEY_NAME", "oscar:notifier:apikey")

    NOTIFIER_APIKEY_FILE: str = os.environ.get(
        "NOTIFIER_APIKEY_FILE", "/run/secrets/notifier_apikey")

    REDIS_PASSWORD: str = os.environ.get("REDIS_PASSWORD", "")
    REDIS_HOST: str = os.environ.get("REDIS_HOST", "redis-stack")
    REDIS_PORT: int = int(os.environ.get("REDIS_PORT", 6379))
    REDIS_URL: str = f"rediss://:{REDIS_PASSWORD}@{REDIS_HOST}:{REDIS_PORT}/0"

    NOTIFIER_SSL_CERT: str = os.environ.get(
        "NOTIFIER_SSL_CERTFILE", "./ssl/notifier/notifier-cert.pem")
    NOTIFIER_SSL_KEY: str = os.environ.get(
        "NOTIFIER_SSL_KEYFILE", "./ssl/notifier/notifier-key.pem")

    ORIGINS: list = os.environ.get("CORE_API_ORIGINS", "*").split(",")

    MIDDLEWARE_HOST: str = os.environ.get("MIDDLEWARE_HOST", "middleware")
    MIDDLEWARE_PORT: int = int(os.environ.get("MIDDLEWARE_PORT", 5200))
    MIDDLEWARE_BASE_URL: str = f"https://{MIDDLEWARE_HOST}:{MIDDLEWARE_PORT}/api/v1"

    CELERY_BROKER_URL: str = os.environ.get(
        "CELERY_BROKER_URL", "rediss://redis-stack:6379/0")
    CELERY_RESULT_BACKEND: str = os.environ.get(
        "CELERY_RESULT_BACKEND", "rediss://redis-stack:6379/0")
    CELERY_FLOWER_URL: str = os.environ.get(
        "CELERY_FLOWER_URL", "http://flower:5555")

    LOGGING_CACHE_KEY: str = os.environ.get(
        "LOGGING_CACHE_KEY", "oscar:logging-cache-key")

    SSL_VERIFY: bool = os.environ.get("SSL_VERIFY", "True") == "True"

    SSL_CERT_REQS: int = ssl.CERT_NONE
    SSL_CA_CERTS: str = os.environ.get("CA_CERTFILE", "../ssl/ca-cert.pem")

    NOTIFIER_DB_LOG_STATEMENTS: bool = os.environ.get(
        "NOTIFIER_DB_LOG_STATEMENTS", "False") == "True"

    NOTIFIER_DB_LOG_CONNECTIONS: bool = os.environ.get(
        "NOTIFIER_DB_LOG_CONNECTIONS", "False") == "True"

    NOTIFIER_DB_CHECK_CONNECTIONS: bool = os.environ.get(
        "NOTIFIER_DB_CHECK_CONNECTIONS", "False") == "True"

from fastapi import HTTPException, Security
from fastapi.security.api_key import APIKeyHeader
from .session import RedisClientSingleton
from .settings import Settings
from app.utils import read_api_key_from_file
import logging

settings = Settings()

logger = logging.getLogger('oscar-metricstore')

api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)

API_KEY = RedisClientSingleton.get_instance().get(
    settings.NOTIFIER_APIKEY_NAME)

if not API_KEY:
    logger.warning(
        f"API Key not found in Redis. Attempting to read from file '{settings.NOTIFIER_APIKEY_NAME}'."
    )
    API_KEY = read_api_key_from_file(settings.NOTIFIER_APIKEY_FILE)

# Check if api_key is a byte string and decode it if necessary
if isinstance(API_KEY, bytes):
    API_KEY = API_KEY.decode('utf-8')


async def validate_api_key(key: str = Security(api_key_header)):
    logger.debug(f"Validating API Key: {key} == {API_KEY}")
    if key != API_KEY:
        raise HTTPException(
            status_code=401, detail="Unauthorized - API Key is wrong"
        )
    return None

import uuid
import json
import logging
import httpx
import threading
from fastapi import HTTPException
from fastapi.encoders import jsonable_encoder
from pydantic import ValidationError
from typing import List, Optional, Dict, Any
from app.core.settings import Settings
from app.core.db import AsyncSession, Notifier, EmailNotifier, EmailAddress, WebhookNotifier
from app.core.db import Task, TaskSchedule, TaskMetadata, TaskArgs, TaskKwargs
from app.core.db import get_async_session, get_async_transaction, apply_filters_to_select
from sqlalchemy import asc, desc, select, and_, delete
from sqlalchemy.sql import func
from sqlalchemy.inspection import inspect
from sqlalchemy.exc import IntegrityError, SQLAlchemyError, NoResultFound
from sqlalchemy.orm import Session, joinedload, selectinload, aliased
from app.utils import async_scheduler_to_tm_format
from app.schemas.common import Pagination, SortEnum, FilterItems
from app.schemas.notifier import NotifierCreate, NotifierUpdate, EmailNotifierCreate, WebhookNotifierCreate
from app.schemas.notifier import TaskScheduleModel, TaskModel, JobConfig, TaskConfig
from app.schemas.notifier import NotifierBase, EmailNotifierResponse, WebhookNotifierResponse
from httpx import AsyncClient

logger = logging.getLogger('oscar-notifier')
settings = Settings()
verify_flag = settings.SSL_VERIFY


class NotifierManagerService:
    _instance = None
    _lock = threading.Lock()

    def __init__(self, db: AsyncSession):
        self.db = db

    @classmethod
    async def get_instance(cls, db: AsyncSession):
        if not cls._instance:
            with cls._lock:
                if cls._instance is None:  # Double-check locking pattern
                    cls._instance = cls(db)
        return cls._instance

    def model_to_dict(self, obj):
        return {c.key: getattr(obj, c.key)
                for c in inspect(obj.__class__).mapper.column_attrs}

    async def ensure_notifier_defaults(self, notifier_data: Dict[str, Any]) -> Dict[str, Any]:
        defaults = {
            "status": "active",
            "created_at": None,
            "modified_at": None
        }

        for key, value in defaults.items():
            if key not in notifier_data or notifier_data[key] is None:
                notifier_data[key] = value

        return notifier_data

    async def get_notifiers(
        self,
        pagination: Pagination,
        column: str,
        filter: Optional[FilterItems] = None
    ):
        async for session in get_async_session():
            try:
                # Determine the sorting attribute
                valid_columns = {col.name for col in inspect(Notifier).c}
                sort_attribute = getattr(
                    Notifier, column) if column in valid_columns else Notifier.name
                sort_clause = desc(
                    sort_attribute) if pagination.order == SortEnum.DESC else asc(sort_attribute)

                # Construct the base query to select Notifiers
                base_query = (
                    select(Notifier)
                    .options(
                        selectinload(Notifier.email_notifier).selectinload(
                            EmailNotifier.email_addresses),
                        selectinload(Notifier.webhook_notifier)
                    )
                    .order_by(sort_clause)
                )

                # Apply filters to the base query
                if filter:
                    base_query = apply_filters_to_select(
                        base_query, filter, [Notifier])

                # Calculate total number of records matching the filter and sorting
                total_records_query = select(
                    func.count()).select_from(base_query.subquery())
                total_records_result = await session.execute(total_records_query)
                total_records = total_records_result.scalar_one()

                # Apply pagination
                paginated_query = base_query.offset(
                    (pagination.page - 1) * pagination.perPage).limit(pagination.perPage)

                # Execute the paginated query
                result = await session.execute(paginated_query)
                notifiers = result.scalars().all()

                logger.debug(
                    f"[Notifier Manager] Notifiers found: {notifiers}")

                # Ensure defaults and convert to Pydantic models
                notifiers_with_defaults = []
                for notifier in notifiers:
                    if notifier.type == 'email' and notifier.email_notifier:
                        notifier_model = EmailNotifierResponse(
                            id=notifier.id,
                            name=notifier.name,
                            description=notifier.description,
                            type=notifier.type,
                            status=notifier.status,
                            created_at=notifier.created_at,
                            modified_at=notifier.modified_at,
                            email_addresses=[
                                email.email for email in notifier.email_notifier.email_addresses]
                        )
                    elif notifier.type == 'webhook' and notifier.webhook_notifier:
                        notifier_model = WebhookNotifierResponse(
                            id=notifier.id,
                            name=notifier.name,
                            description=notifier.description,
                            type=notifier.type,
                            status=notifier.status,
                            created_at=notifier.created_at,
                            modified_at=notifier.modified_at,
                            url=notifier.webhook_notifier.url
                        )
                    else:
                        notifier_model = NotifierBase(
                            id=notifier.id,
                            name=notifier.name,
                            description=notifier.description,
                            type=notifier.type,
                            status=notifier.status,
                            created_at=notifier.created_at,
                            modified_at=notifier.modified_at,
                        )
                    notifiers_with_defaults.append(notifier_model)

                logger.debug(
                    f"[Notifier Manager] Final notifiers with defaults: {notifiers_with_defaults}")

                return {"total_records": total_records, "records": notifiers_with_defaults}

            except SQLAlchemyError as e:
                logger.error(f"Database error while retrieving notifiers: {e}")
                raise HTTPException(
                    status_code=500, detail="An error occurred while retrieving notifiers.")
            except Exception as e:
                logger.error(
                    f"Unexpected error occurred while retrieving notifiers: {e}")
                raise HTTPException(
                    status_code=500, detail="An unexpected error occurred while retrieving notifiers.")

    async def add_notifier(
        self,
        notifier: NotifierCreate,
    ) -> Optional[Notifier]:

        # Add the notifier to the database
        async with get_async_transaction() as transaction:
            try:
                # Create a new ORM Notifier object
                orm_notifier = Notifier(
                    name=notifier.name,
                    description=notifier.description,
                    type=notifier.type,
                    status=notifier.status
                )

                transaction.add(orm_notifier)
                await transaction.flush()  # Ensure the Notifier is added to the session

                if notifier.type == 'email' and notifier.email_notifier:
                    email_notifier = EmailNotifier(
                        notifier_id=orm_notifier.id,
                        email_addresses=[EmailAddress(
                            email=email.email) for email in notifier.email_notifier.email_addresses]
                    )
                    transaction.add(email_notifier)
                    await transaction.flush()  # Ensure email_notifier is added to the session

                    # Add email addresses to kwargs
                    email_addresses_json = json.dumps(
                        [email.email for email in notifier.email_notifier.email_addresses]
                    )
                    task_kwargs = {
                        '__email_notifier_targets__': email_addresses_json,
                        '__notifier_type__': notifier.type
                    }

                elif notifier.type == 'webhook' and notifier.webhook_notifier:
                    webhook_notifier = WebhookNotifier(
                        notifier_id=orm_notifier.id,
                        url=notifier.webhook_notifier.url,
                    )
                    transaction.add(webhook_notifier)
                    await transaction.flush()  # Ensure webhook_notifier is added to the session

                    # Add webhook URL to kwargs
                    task_kwargs = {
                        '__webhook_endpoint__': notifier.webhook_notifier.url,
                        '__notifier_type__': notifier.type
                    }
                else:
                    task_kwargs = {}

                # Create task schedule object
                schedule_model = None
                if notifier.schedule:
                    schedule_model = notifier.schedule

                # Create a new task config object to add the notifier to the task manager
                task_config = TaskConfig(
                    name=f"notifier:{orm_notifier.name.lower()}",
                    status=orm_notifier.status,
                    type='celery',
                    owner='internal',
                    organization='internal',
                    description=orm_notifier.description,
                    schedule=schedule_model,
                    args=None,
                    kwargs=task_kwargs,
                    metadata={},
                    prompts=None,
                    environments=None,
                    components=None,
                    datacenter=None,
                    hosts=[],
                    promptForCredentials=False,
                    promptForAPIKey=False,
                )

                # Add headers to kwargs if it is a webhook
                if notifier.type == 'webhook':
                    if task_config.kwargs is None:
                        task_config.kwargs = {}

                    if notifier.webhook_notifier and notifier.webhook_notifier.headers:
                        task_config.kwargs['__headers__'] = json.dumps(
                            notifier.webhook_notifier.headers)

                    if notifier.webhook_notifier and notifier.webhook_notifier.url:
                        task_config.kwargs['__endpoint__'] = notifier.webhook_notifier.url

                # Log the task configuration being registered
                logger.debug(
                    f"[Register Notifier]: registering {task_config.name}")

                task, is_new_task = await self.get_or_create_task(transaction, task_config)
                await self.update_task_details(task, task_config, transaction, is_new_task)
                await self.update_schedule(task, task_config, transaction, is_new_task)
                await self.update_args(task, task_config, transaction, is_new_task)
                await self.update_kwargs(task, task_config, transaction, is_new_task)
                await self.update_metadata(task, task_config, transaction, is_new_task)

                # Explicitly load the relationships to avoid DetachedInstanceError
                await transaction.refresh(orm_notifier)

                # Eagerly load the relationships
                orm_notifier = await transaction.execute(
                    select(Notifier)
                    .options(selectinload(Notifier.email_notifier).selectinload(EmailNotifier.email_addresses),
                             selectinload(Notifier.webhook_notifier))
                    .where(Notifier.id == orm_notifier.id)
                )
                orm_notifier = orm_notifier.scalars().first()

            except ValidationError as e:
                logger.error(f"Validation error: {e}")
                raise  # This will trigger the transaction rollback in the context manager
            except IntegrityError as e:
                logger.error(
                    f"[Register Notifier]: Integrity Error while processing task '{task_config.name}': {e}")
                raise HTTPException(
                    status_code=400, detail=f"Error while processing task '{task_config.name}'")
            except SQLAlchemyError as e:
                logger.error(
                    f"[Register Notifier]: SQLAlchemy Error while processing task '{task_config.name}': {e}")
                raise HTTPException(
                    status_code=500, detail=f"Error while processing task '{task_config.name}'")
            except Exception as e:
                logger.error(
                    f"[Register Notifier]: Unexpected error occurred while processing task '{task_config.name}': {e}")
                raise HTTPException(
                    status_code=500, detail="Unexpected error occurred")

        return orm_notifier

    async def update_notifier(
        self,
        id: str,
        notifier: NotifierUpdate,
    ) -> Optional[Notifier]:
        async for session in get_async_session():
            try:
                async with session.begin():
                    stmt = select(Notifier).filter(Notifier.id == id)
                    result = await session.execute(stmt)
                    notifier_to_update = result.scalars().first()

                    if not notifier_to_update:
                        logger.info(f"Notifier with ID '{id}' not found.")
                        return None

                    if notifier.name is not None:
                        notifier_to_update.name = notifier.name

                    if notifier.description is not None:
                        notifier_to_update.description = notifier.description

                    if notifier.status is not None:
                        notifier_to_update.status = notifier.status

                    if notifier.schedule is not None:
                        task_name_pattern = f'notifier:{notifier_to_update.name}'
                        task_stmt = select(Task).filter(
                            Task.name == task_name_pattern)
                        task_result = await session.execute(task_stmt)
                        tasks = task_result.scalars().all()

                        for task in tasks:
                            task_config = TaskConfig(
                                name=f"notifier:{notifier_to_update.name.lower()}",
                                status=notifier_to_update.status,
                                type=task.type,
                                owner=task.owner,
                                organization=task.organization,
                                description=notifier_to_update.description,
                                schedule=notifier.schedule,
                                args=None,
                                kwargs={},
                                metadata={},
                                prompts=None,
                                environments=None,
                                components=None,
                                datacenter=None,
                                hosts=[],
                                promptForCredentials=False,
                                promptForAPIKey=False,
                            )

                            is_new_task = False
                            await self.update_task_details(task, task_config, session, is_new_task)
                            await self.update_schedule(task, task_config, session, is_new_task)
                            await self.update_args(task, task_config, session, is_new_task)
                            await self.update_kwargs(task, task_config, session, is_new_task)
                            await self.update_metadata(task, task_config, session, is_new_task)

                    await session.commit()

                    return notifier_to_update
            except SQLAlchemyError as e:
                logger.error(f"Database error while updating notifier: {e}")
                await session.rollback()
                return None

    async def delete_notifier(self, id: str) -> bool:
        async for session in get_async_session():
            try:
                async with session.begin():
                    stmt = select(Notifier).filter(Notifier.id == id)
                    result = await session.execute(stmt)
                    notifier = result.scalars().first()

                    if notifier:
                        task_name_pattern = f'notifier:{notifier.name.lower()}'
                        task_stmt = select(Task).filter(
                            Task.name == task_name_pattern)
                        task_result = await session.execute(task_stmt)
                        tasks = task_result.scalars().all()

                        # Log the tasks to be deleted
                        logger.debug(
                            f"Deleting tasks associated with notifier {notifier.name}: {[task.id for task in tasks]}")

                        for task in tasks:
                            await session.delete(task)

                            # Unscheduling the task from the scheduler
                            job_id = f"{task.name}_{task.id}"
                            try:
                                await self._unschedule_job(job_id)
                            except Exception as e:
                                logger.error(
                                    f"Failed to unschedule job {job_id}. Error: {e}")

                        # Delete the notifier and its associated email or webhook notifier
                        if notifier.type == 'email':
                            email_notifier_stmt = select(EmailNotifier).filter(
                                EmailNotifier.notifier_id == notifier.id)
                            email_notifier_result = await session.execute(email_notifier_stmt)
                            email_notifier = email_notifier_result.scalars().first()
                            if email_notifier:
                                await session.delete(email_notifier)

                        elif notifier.type == 'webhook':
                            webhook_notifier_stmt = select(WebhookNotifier).filter(
                                WebhookNotifier.notifier_id == notifier.id)
                            webhook_notifier_result = await session.execute(webhook_notifier_stmt)
                            webhook_notifier = webhook_notifier_result.scalars().first()
                            if webhook_notifier:
                                await session.delete(webhook_notifier)

                        # Finally, delete the main notifier
                        try:
                            await session.delete(notifier)
                            # await session.commit()
                            # await session.flush()  # Ensure any cached data is flushed
                            # # Explicitly refresh the session
                            # await session.refresh(notifier)

                            logger.debug(
                                f"Deleted notifier {id} and committed transaction")
                            return True
                        except Exception as e:
                            logger.error(
                                f"Failed to delete notifier with ID {id}: {e}")
                            await session.rollback()
                            return False

                    else:
                        logger.warning(f"Notifier with ID {id} not found.")
                        return False
            except NoResultFound:
                logger.info(f"Notifier with ID '{id}' not found.")
                return False
            except SQLAlchemyError as e:
                logger.error(f"Database error while deleting Notifier: {e}")
                await session.rollback()  # Ensure rollback in case of errors
                return False
            except Exception as e:
                logger.error(
                    f"Failed to delete notifier with ID {id} and associated tasks: {e}")
                await session.rollback()
                return False

        return False

    async def disable_notifiers(self, notifier_ids: List[str]):
        updated_notifiers = []
        async for session in get_async_session():
            for notifier_id in notifier_ids:
                async with session.begin():
                    stmt = select(Notifier).filter(Notifier.id == notifier_id)
                    result = await session.execute(stmt)
                    notifier = result.scalars().first()

                    if notifier and notifier.status != 'disabled':
                        notifier.status = 'disabled'
                        try:
                            task_name_pattern = f'notifier:{notifier.name}'
                            task_stmt = select(Task).filter(
                                Task.name.like(f"{task_name_pattern}%"))
                            task_result = await session.execute(task_stmt)
                            tasks = task_result.scalars().all()

                            # Log the tasks to be disabled
                            logger.debug(
                                f"Disabling tasks associated with notifier {notifier.name}: {[task.id for task in tasks]}")  # noqa

                            for task in tasks:
                                if task.status != 'disabled':
                                    task.status = 'disabled'
                                    try:
                                        await self._pause_job(f"{task.name}_{task.id}")
                                    except Exception as e:
                                        logger.error(
                                            f"Failed to pause job for task {task.id}: {e}")

                            await session.commit()
                            updated_notifiers.append(notifier_id)
                            logger.info(
                                f"Notifier with ID {notifier_id} disabled successfully.")
                        except Exception as e:
                            await session.rollback()
                            logger.error(
                                f"Failed to disable notifier with ID {notifier_id}: {e}")
                    else:
                        logger.warning(
                            f"Notifier with ID {notifier_id} not found or already inactive.")

                        if notifier:
                            # Also check and disable associated tasks even if notifier was not found or already inactive
                            task_name_pattern = f'notifier:{notifier.name}'
                            task_stmt = select(Task).filter(
                                Task.name.like(f"{task_name_pattern}%"))
                            task_result = await session.execute(task_stmt)
                            tasks = task_result.scalars().all()

                            for task in tasks:
                                if task.status != 'disabled':
                                    task.status = 'disabled'
                                    try:
                                        await session.commit()
                                        logger.info(
                                            f"Task {task.id} associated with notifier {notifier_id} disabled successfully.")  # noqa
                                        await self._pause_job(f"{task.name}_{task.id}")
                                    except Exception as e:
                                        await session.rollback()
                                        logger.error(
                                            f"Failed to disable task with ID {task.id} associated with notifier {notifier_id}: {e}")  # noqa

        return updated_notifiers

    async def enable_notifiers(self, notifier_ids: List[str]):
        updated_notifiers = []
        async for session in get_async_session():
            for notifier_id in notifier_ids:
                async with session.begin():
                    stmt = select(Notifier).filter(Notifier.id == notifier_id)
                    result = await session.execute(stmt)
                    notifier = result.scalars().first()

                    if notifier and notifier.status != 'enabled':
                        notifier.status = 'enabled'
                        try:
                            task_name_pattern = f'notifier:{notifier.name}'
                            task_stmt = select(Task).filter(
                                Task.name.like(f"{task_name_pattern}%"))
                            task_result = await session.execute(task_stmt)
                            tasks = task_result.scalars().all()

                            # Log the tasks to be enabled
                            logger.debug(
                                f"Enabling tasks associated with notifier {notifier.name}: {[task.id for task in tasks]}")  # noqa
                            for task in tasks:
                                if task.status != 'enabled':
                                    task.status = 'enabled'
                                    try:
                                        await self._resume_job(f"{task.name}_{task.id}")
                                    except Exception as e:
                                        logger.error(
                                            f"Failed to resume job for task {task.id}: {e}")

                            await session.commit()
                            updated_notifiers.append(notifier_id)
                            logger.info(
                                f"Notifier with ID {notifier_id} enabled successfully.")
                        except Exception as e:
                            await session.rollback()
                            logger.error(
                                f"Failed to enable notifier with ID {notifier_id}: {e}")
                    else:
                        logger.warning(
                            f"Notifier with ID {notifier_id} not found or already active.")

                        if notifier:
                            # Also check and enable associated tasks even if notifier was not found or already active
                            task_name_pattern = f'notifier:{notifier.name}'
                            task_stmt = select(Task).filter(
                                Task.name.like(f"{task_name_pattern}%"))
                            task_result = await session.execute(task_stmt)
                            tasks = task_result.scalars().all()

                            for task in tasks:
                                if task.status != 'enabled':
                                    task.status = 'enabled'
                                    try:
                                        await session.commit()
                                        logger.info(
                                            f"Task {task.id} associated with notifier {notifier_id} enabled successfully.")  # noqa
                                        await self._resume_job(f"{task.name}_{task.id}")
                                    except Exception as e:
                                        await session.rollback()
                                        logger.error(
                                            f"Failed to enable task with ID {task.id} associated with notifier {notifier_id}: {e}")  # noqa

        return updated_notifiers

    async def get_or_create_task(self, transaction, task_config):
        stmt = select(Task).where(Task.name == task_config.name)
        result = await transaction.execute(stmt)
        task = result.scalars().first()

        if not task:
            logger.info(
                f"[Register Notifier]: Adding new task: {task_config.name}")

            celery_job_name = await async_scheduler_to_tm_format(task_config.name)

            task = Task(
                name=task_config.name,
                celery_job_name=celery_job_name,
                type=task_config.type,
                status=task_config.status,
                owner=task_config.owner,
                organization=task_config.organization
            )

            if task_config.description:
                task.description = task_config.description

            transaction.add(task)
            await transaction.flush()  # Flush to get the task id

            logger.debug(
                f"[Register Notifier]: Newly Created Task: {task.id}")
            return task, True

        return task, False

    async def update_task_details(self, task, task_config, transaction, is_new_task):
        task.type = task_config.type
        task.status = task_config.status
        task.owner = task_config.owner
        task.organization = task_config.organization

        if task_config.description:
            task.description = task_config.description

        if is_new_task:
            transaction.add(task)

        await transaction.flush()  # Flush to get the task id

    async def update_schedule(self, task, task_config, transaction, is_new_task):
        if task_config.schedule:
            if task_config.schedule.start_date == '':
                task_config.schedule.start_date = None
            if task_config.schedule.end_date == '':
                task_config.schedule.end_date = None

            if not is_new_task:
                stmt = select(TaskSchedule).where(
                    TaskSchedule.task_id == task.id)
                result = await transaction.execute(stmt)
                schedule = result.scalars().first()

                if schedule:
                    if task_config.schedule.minute:
                        schedule.minute = str(task_config.schedule.minute)

                    if task_config.schedule.hour:
                        schedule.hour = str(task_config.schedule.hour)

                    if task_config.schedule.day_of_week:
                        schedule.day_of_week = str(
                            task_config.schedule.day_of_week)

                    if task_config.schedule.day:
                        schedule.day = str(task_config.schedule.day)

                    if task_config.schedule.month:
                        schedule.month = str(task_config.schedule.month)

                    if task_config.schedule.year:
                        schedule.year = str(task_config.schedule.year)

                    if task_config.schedule.start_date:
                        schedule.start_date = task_config.schedule.start_date

                    if task_config.schedule.end_date:
                        schedule.end_date = task_config.schedule.end_date

                    if task_config.schedule.timezone:
                        schedule.timezone = task_config.schedule.timezone

                    if task_config.schedule.jitter:
                        schedule.jitter = task_config.schedule.jitter
            else:
                new_schedule = TaskSchedule(
                    task_id=task.id,
                    minute=task_config.schedule.minute,
                    hour=task_config.schedule.hour,
                    day_of_week=task_config.schedule.day_of_week,
                    day=task_config.schedule.day,
                    month=task_config.schedule.month,
                    year=task_config.schedule.year,
                    start_date=task_config.schedule.start_date,
                    end_date=task_config.schedule.end_date,
                    timezone=task_config.schedule.timezone,
                    jitter=task_config.schedule.jitter
                )
                transaction.add(new_schedule)

    async def update_args(self, task, task_config, transaction, is_new_task):
        if task_config.args:
            if not is_new_task:
                await transaction.execute(
                    delete(TaskArgs).where(TaskArgs.task_id == task.id)
                )
                await transaction.flush()

            for index, arg_value in enumerate(task_config.args):
                new_arg = TaskArgs(
                    task_id=task.id,
                    value=arg_value,
                    sequence=index
                )
                transaction.add(new_arg)

            await transaction.flush()
        else:
            await transaction.execute(
                delete(TaskArgs).where(TaskArgs.task_id == task.id)
            )
            await transaction.flush()

    async def update_kwargs(self, task, task_config, transaction, is_new_task):
        if task_config.kwargs:
            if not is_new_task:
                await transaction.execute(
                    delete(TaskKwargs).where(TaskKwargs.task_id == task.id)
                )
                await transaction.flush()

            current_kwargs = {}
            result = await transaction.execute(
                select(TaskKwargs).where(TaskKwargs.task_id == task.id)
            )
            existing_kwargs = result.scalars().all()
            current_kwargs = {kwarg.key: kwarg for kwarg in existing_kwargs}

            for key, value in task_config.kwargs.items():
                if key in current_kwargs:
                    current_kwargs[key].value = value
                else:
                    new_kwarg = TaskKwargs(
                        task_id=task.id,
                        key=key,
                        value=value
                    )
                    transaction.add(new_kwarg)

            extra_keys = set(current_kwargs.keys()) - \
                set(task_config.kwargs.keys())
            for key in extra_keys:
                await transaction.delete(current_kwargs[key])

            await transaction.flush()
        else:
            await transaction.execute(
                delete(TaskKwargs).where(TaskKwargs.task_id == task.id)
            )
            await transaction.flush()

    async def update_metadata(self, task, task_config, transaction, is_new_task):
        if task_config.metadata:
            if not is_new_task:
                await transaction.execute(
                    delete(TaskMetadata).where(TaskMetadata.task_id == task.id)
                )
                await transaction.flush()

            current_metadata = {}
            result = await transaction.execute(
                select(TaskMetadata).where(TaskMetadata.task_id == task.id)
            )
            existing_metadata = result.scalars().all()
            current_metadata = {
                metadata.key: metadata for metadata in existing_metadata}

            for key, value in task_config.metadata.items():
                if key in current_metadata:
                    current_metadata[key].value = value
                else:
                    new_metadata = TaskMetadata(
                        task_id=task.id,
                        key=key,
                        value=value
                    )
                    transaction.add(new_metadata)

            extra_keys = set(current_metadata.keys()) - \
                set(task_config.metadata.keys())
            for key in extra_keys:
                await transaction.delete(current_metadata[key])

            await transaction.flush()
        else:
            await transaction.execute(
                delete(TaskMetadata).where(TaskMetadata.task_id == task.id)
            )
            await transaction.flush()

    async def get_task_by_name(self, task_name: str) -> Optional[TaskModel]:
        async for session in get_async_session():
            stmt = (
                select(Task).
                options(
                    joinedload(Task.schedule),
                    joinedload(Task.args),
                    joinedload(Task.kwargs),
                    joinedload(Task.task_metadata)
                ).
                filter(Task.name == task_name)
            )
            result = await session.execute(stmt)
            task = result.scalars().first()
            return await self.task_to_model(task) if task else None

    async def task_to_model(self, task):
        # Transform SQLAlchemy objects to Pydantic models
        schedule_model = TaskScheduleModel(
            id=task.schedule.id if task.schedule else None,
            task_id=task.id if task.schedule else None,
            year=task.schedule.year if task.schedule else None,
            month=task.schedule.month if task.schedule else None,
            day=task.schedule.day if task.schedule else None,
            week=task.schedule.week if task.schedule else None,
            day_of_week=task.schedule.day_of_week if task.schedule else None,
            hour=task.schedule.hour if task.schedule else None,
            minute=task.schedule.minute if task.schedule else None,
            second=task.schedule.second if task.schedule else None,
            start_date=task.schedule.start_date if task.schedule else None,
            end_date=task.schedule.end_date if task.schedule else None,
            timezone=task.schedule.timezone if task.schedule else None,
            jitter=task.schedule.jitter if task.schedule else None,
            created_at=task.schedule.created_at if task.schedule else None,
            modified_at=task.schedule.modified_at if task.schedule else None
        ) if task.schedule else None

        args_list = [arg.value for arg in task.args]
        kwargs_dict = {kwarg.key: kwarg.value for kwarg in task.kwargs}
        metadata_dict = {meta.key: meta.value for meta in task.task_metadata}

        # Check if the task is scheduled and enabled
        if task.schedule and task.status == "active":
            base_url = settings.MIDDLEWARE_BASE_URL
            async with httpx.AsyncClient(verify=verify_flag) as client:
                try:
                    # Construct job_id from task details
                    job_id = f"{task.name}_{task.id}"
                    logger.debug(f"Fetching next run time for job {job_id}")

                    # Make API call to middleware to get next run time
                    response = await client.get(
                        f"{base_url}/scheduler/jobs/{job_id}"
                    )
                    if response.status_code == 200:
                        job_data = response.json()
                        next_run_time = job_data.get("next_run_time")

                        if next_run_time:
                            logger.debug(
                                f"Next run time for job {job_id}: {next_run_time}")
                    else:
                        logger.warning(
                            f"Failed to fetch next run time for task {task.id}.")
                        next_run_time = None
                except Exception as e:
                    # Handle exceptions, log error, etc.
                    logger.error(
                        f"Error fetching next run time for task {task.id}: {e}")
                    next_run_time = None
        else:
            next_run_time = None

        return TaskModel(
            id=task.id,
            name=task.name,
            celery_job_name=task.celery_job_name,
            type=task.type,
            status=task.status,
            owner=task.owner,
            organization=task.organization,
            next_run_time=next_run_time,
            description=task.description,
            schedule=schedule_model,
            args=args_list,
            kwargs=kwargs_dict,
            metadata=metadata_dict,
            created_at=task.created_at,
            modified_at=task.modified_at,
            prompts=None,
            hosts=[]
        )

    async def get_task_by_id(self, task_id: str) -> Optional[TaskModel]:
        async for session in get_async_session():
            stmt = (
                select(Task).
                options(
                    joinedload(Task.schedule),
                    joinedload(Task.args),
                    joinedload(Task.kwargs),
                    joinedload(Task.task_metadata)
                ).
                filter(Task.id == task_id)
            )
            result = await session.execute(stmt)
            task = result.scalars().first()
            return await self.task_to_model(task) if task else None

    async def task_needs_scheduling(self, task: TaskModel) -> bool:
        if task.status.lower() != "inactive":
            if task.schedule:
                scheduling_fields = ["year", "month", "day", "hour", "minute"]
                for field in scheduling_fields:
                    if getattr(task.schedule, field, None) is not None:
                        return True
        return False

    async def _prepare_job_data(self, task_data: TaskModel) -> Optional[JobConfig]:
        try:
            if not task_data.name:
                raise ValueError("Task 'name' is missing or null")

            job_data = JobConfig(
                id=str(task_data.id),
                type=task_data.type,
                name=task_data.name,
                schedule=task_data.schedule,
                args=task_data.args or [],
                kwargs=task_data.kwargs or {}
            )

            return job_data

        except ValueError as e:
            logger.error(f"Error in _prepare_job_data: {e}")
            return None

        except Exception as e:
            logger.error(f"Unexpected error in _prepare_job_data: {e}")
            return None

    async def _schedule_job(self, job_data: JobConfig) -> Optional[dict]:
        base_url = settings.MIDDLEWARE_BASE_URL  # type: ignore
        async with httpx.AsyncClient(verify=verify_flag) as client:
            try:
                response = await client.post(
                    f"{base_url}/scheduler/jobs",
                    json=jsonable_encoder(job_data)
                )
                response.raise_for_status()

                job_response_data = response.json()

                return job_response_data
            except httpx.HTTPStatusError as exc:
                if exc.response is not None:
                    try:
                        error_detail = exc.response.json().get('detail', str(exc))
                    except ValueError:
                        error_detail = str(exc)
                    raise HTTPException(
                        status_code=exc.response.status_code,
                        detail=f"Error from underlying API {base_url}/scheduler/jobs: {error_detail}"
                    )
                else:
                    raise HTTPException(
                        status_code=500,
                        detail="An unexpected error occurred."
                    )
            except httpx.RequestError as exc:
                raise HTTPException(status_code=500, detail=str(exc))
            except Exception as exc:
                raise HTTPException(
                    status_code=500,
                    detail=f"An unexpected error occurred: {str(exc)}"
                )

    async def _unschedule_job(self, job_id: str) -> Optional[dict]:
        base_url = settings.MIDDLEWARE_BASE_URL
        async with httpx.AsyncClient(verify=verify_flag) as client:
            try:
                await client.delete(
                    f"{base_url}/scheduler/jobs/{job_id}"
                )

            except httpx.HTTPStatusError as exc:
                if exc.response is not None:
                    try:
                        error_detail = exc.response.json().get('detail', str(exc))
                    except ValueError:
                        error_detail = str(exc)
                    raise HTTPException(
                        status_code=exc.response.status_code,
                        detail=f"Error from underlying API {base_url}/scheduler/jobs/{job_id}: {error_detail}"
                    )
            except httpx.RequestError as exc:
                raise HTTPException(status_code=500, detail=str(exc))

    async def _pause_job(self, job_id: str) -> Optional[dict]:
        base_url = settings.MIDDLEWARE_BASE_URL
        async with httpx.AsyncClient(verify=verify_flag) as client:
            try:
                response = await client.post(
                    f"{base_url}/scheduler/jobs/{job_id}/pause"
                )
                response.raise_for_status()

                if response.status_code == 202:
                    logger.info(
                        f"Paused job with ID {job_id} and response: {response}")

                return response.json()
            except httpx.HTTPStatusError as exc:
                if exc.response is not None:
                    try:
                        error_detail = exc.response.json().get('detail', str(exc))
                    except ValueError:
                        error_detail = str(exc)
                    raise HTTPException(
                        status_code=exc.response.status_code,
                        detail=f"Error from underlying API {base_url}/scheduler/jobs/{job_id}/pause: {error_detail}"
                    )
            except httpx.RequestError as exc:
                raise HTTPException(status_code=500, detail=str(exc))

    async def _resume_job(self, job_id: str) -> Optional[dict]:
        base_url = settings.MIDDLEWARE_BASE_URL
        async with httpx.AsyncClient(verify=verify_flag) as client:
            try:
                response = await client.post(
                    f"{base_url}/scheduler/jobs/{job_id}/resume"
                )
                response.raise_for_status()

                if response.status_code == 202:
                    logger.info(
                        f"Resumed job with ID {job_id} and response: {response}")

                return response.json()
            except httpx.HTTPStatusError as exc:
                if exc.response is not None:
                    try:
                        error_detail = exc.response.json().get('detail', str(exc))
                    except ValueError:
                        error_detail = str(exc)
                    raise HTTPException(
                        status_code=exc.response.status_code,
                        detail=f"Error from underlying API {base_url}/scheduler/jobs/{job_id}/resume: {error_detail}"
                    )
            except httpx.RequestError as exc:
                raise HTTPException(status_code=500, detail=str(exc))

import logging
import logging.config
import yaml
import queue
import sys
from pathlib import Path
from logging.handlers import QueueHandler, QueueListener, TimedRotatingFileHandler, SysLogHandler
from core.session import RedisClientSingleton
from pythonjsonlogger import jsonlogger
from .settings import Settings


class LoggerSetup:
    def __init__(self, config_key=None):
        self.config_key = config_key or Settings().LOGGING_CACHE_KEY
        self.queue_listener = None
        self.setup_logging()

    def fetch_logging_config(self):
        try:
            client = RedisClientSingleton.get_instance()
            config_str = client.get(self.config_key)
            if config_str:
                return yaml.safe_load(config_str)  # type: ignore
            else:
                raise Exception("Logging configuration not found in Redis")
        except Exception as e:
            print(f"[FAILED] to fetch logging configuration: {e}")
            return None

    def setup_logging(self):
        config = self.fetch_logging_config()
        if config:
            logging.config.dictConfig(config)

            # Create a queue for log messages
            log_queue = queue.Queue(-1)

            # Create a handler for the queue
            queue_handler = QueueHandler(log_queue)

            # Retrieve actual handlers from the configuration
            handlers = []
            for handler_name, handler_config in config['handlers'].items():
                if handler_name != 'queue_handler':
                    handler = self.create_handler(handler_config, config)
                    if handler:
                        handlers.append(handler)

            self.queue_listener = QueueListener(log_queue, *handlers)
            self.queue_listener.start()

            # Add QueueHandler to root logger
            root_logger = logging.getLogger()
            root_logger.addHandler(queue_handler)
        else:
            print("[FAILED] to setup logging")

    def create_handler(self, handler_config, config):
        # Create a logging handler based on the provided configuration
        handler_type = handler_config['class']
        if handler_type == 'logging.StreamHandler':
            return self._create_stream_handler(handler_config, config)
        elif handler_type == 'logging.handlers.TimedRotatingFileHandler':
            return self._create_timed_rotating_file_handler(handler_config, config)
        elif handler_type == 'logging.handlers.SysLogHandler':
            return self._create_syslog_handler(handler_config, config)
        else:
            raise ValueError(f"Unknown handler type: {handler_type}")

    def _create_stream_handler(self, config, global_config):
        stream = config.get('stream')

        # Convert string representation to actual stream object
        if stream == 'ext://sys.stdout':
            stream = sys.stdout
        elif stream == 'ext://sys.stderr':
            stream = sys.stderr

        # Create a StreamHandler
        handler = logging.StreamHandler(stream=stream)
        handler.setLevel(config.get('level', 'DEBUG'))
        handler.setFormatter(self._get_formatter(
            config.get('formatter'), global_config))
        return handler

    def _create_timed_rotating_file_handler(self, config, global_config):
        # Create a TimedRotatingFileHandler
        filename = config.get('filename')
        if filename:
            filename = Path(filename).absolute()
        handler = TimedRotatingFileHandler(
            filename,
            when=config.get('when', 'midnight'),
            interval=config.get('interval', 1),
            backupCount=config.get('backupCount', 5),
            encoding=config.get('encoding', 'utf8')
        )
        handler.setLevel(config.get('level', 'DEBUG'))
        handler.setFormatter(self._get_formatter(
            config.get('formatter'), global_config))
        return handler

    def _create_syslog_handler(self, config, global_config):
        address = config.get('address')
        handler = None

        # Convert address to a tuple if it's a list
        if isinstance(address, list):
            # Ensure that the list has two elements: host and port
            if len(address) == 2 and isinstance(address[0], str) and isinstance(address[1], int):
                address_tuple = (address[0], address[1])
                handler = SysLogHandler(address=address_tuple)
                handler.setLevel(config.get('level', 'DEBUG'))
                handler.setFormatter(self._get_formatter(
                    config.get('formatter'), global_config))
            else:
                raise ValueError(
                    "SysLogHandler address must be a list with two elements: [host, port]")

        # Convert address to a tuple if it's a single string
        elif isinstance(address, str) and ":" in address:
            try:
                host, port_str = address.split(":", 1)
                port = int(port_str)
                address_tuple = (host, port)
                handler = SysLogHandler(address=address_tuple)
                handler.setLevel(config.get('level', 'DEBUG'))
                handler.setFormatter(self._get_formatter(
                    config.get('formatter'), global_config))
            except ValueError:
                raise ValueError(
                    "Invalid SysLogHandler address format. Expected 'host:port' or ['host', port]")

        return handler

    def _get_formatter(self, formatter_name, config):
        # Create and return a formatter based on its name using the configuration dictionary
        formatter_config = config['formatters'].get(formatter_name)
        if not formatter_config:
            raise ValueError(
                f"Formatter configuration for '{formatter_name}' not found")

        if formatter_name == 'json':
            return jsonlogger.JsonFormatter(
                fmt=formatter_config.get('format'),
                datefmt=formatter_config.get('datefmt')
            )
        else:
            return logging.Formatter(
                fmt=formatter_config.get('format'),
                datefmt=formatter_config.get('datefmt')
            )

    def get_logger(self, name=None):
        return logging.getLogger(name)

    def get_queue_listener(self):
        return self.queue_listener

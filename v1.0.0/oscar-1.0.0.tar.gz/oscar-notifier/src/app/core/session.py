import redis
from .settings import Settings
from redis import asyncio as aioredis
from redis.asyncio.connection import ConnectionPool

settings = Settings()


class RedisClientSingleton:
    _instance = None

    @staticmethod
    def get_instance():
        if RedisClientSingleton._instance is None:
            # Customize connection pool
            pool = redis.ConnectionPool.from_url(
                settings.REDIS_URL,
                max_connections=20,
                socket_timeout=0.5,
                socket_connect_timeout=1.0,
                ssl_cert_reqs=settings.SSL_CERT_REQS,
                ssl_ca_certs=settings.SSL_CA_CERTS
            )
            RedisClientSingleton._instance = redis.Redis(connection_pool=pool)
        return RedisClientSingleton._instance


class AsyncRedisClientSingleton:
    _instance = None

    @staticmethod
    def get_instance():
        if AsyncRedisClientSingleton._instance is None:
            # Customize connection pool
            pool = ConnectionPool.from_url(
                settings.REDIS_URL,
                max_connections=20,
                socket_timeout=0.5,
                socket_connect_timeout=1.0,
                ssl_check_hostname=settings.SSL_VERIFY,
                ssl_cert_reqs="none",
                ssl_ca_certs=settings.SSL_CA_CERTS,
            )
            AsyncRedisClientSingleton._instance = aioredis.Redis(
                connection_pool=pool)
        return AsyncRedisClientSingleton._instance

from datetime import datetime, timedelta, timezone
import os
import logging
from typing import Optional
from fastapi import Query
from .schemas.common import SortEnum, Pagination
import dateutil.parser

logger = logging.getLogger("oscar-metricstore")


def read_api_key_from_file(file_path: str) -> str:
    # Check if the file exists
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"API key file not found at '{file_path}'.")

    # Read the content of the file
    with open(file_path, 'r') as file:
        api_key = file.read().strip()

    # Check if the file has content (i.e., the API key)
    if not api_key:
        raise ValueError(
            f"The file at '{file_path}' is empty. API key is required.")

    return api_key


def format_uptime(seconds):
    days, remainder = divmod(seconds, 86400)  # 86400 seconds in a day
    hours, remainder = divmod(remainder, 3600)  # 3600 seconds in an hour
    minutes, seconds = divmod(remainder, 60)  # 60 seconds in a minute
    # Format the uptime string
    if days:
        formatted_uptime = f"{days}d {hours}h {minutes}m {seconds}s"
    elif hours:
        formatted_uptime = f"{hours}h {minutes}m {seconds}s"
    elif minutes:
        formatted_uptime = f"{minutes}m {seconds}s"
    else:
        formatted_uptime = f"{seconds}s"
    return formatted_uptime


async def safe_parse_datetime(date_str):
    """Attempt to parse a date string into a datetime object. Return None if parsing fails."""
    try:
        return dateutil.parser.parse(date_str)
    except (TypeError, ValueError):
        return None


def convert_to_utc(timestamp: datetime) -> Optional[datetime]:
    """
    Converts a timezone-aware datetime object to UTC.
    If the input datetime is not timezone-aware, returns None.

    :param timestamp: The timezone-aware datetime object to convert.
    :return: The converted datetime object in UTC, or None if input is not timezone-aware.
    """
    if timestamp and timestamp.tzinfo:
        return timestamp.astimezone(timezone.utc)
    else:
        # Optionally, log a warning or raise an exception based on your application's needs
        print("Provided timestamp is not timezone-aware.")
        return None


def pagination_params(
        page: int = Query(ge=1, default=1, required=False, le=50000),
        perPage: int = Query(ge=1, le=100, default=10, required=False),
        order: SortEnum = Query(default=SortEnum.DESC, required=False)
):
    return Pagination(page=page, perPage=perPage, order=order)


def get_rolling_period(period: int, end_date: datetime) -> tuple[datetime, datetime]:
    end_date = (end_date - timedelta(days=1)).replace(
        hour=23, minute=59, second=59, microsecond=999999)
    start_date = end_date - timedelta(days=period)
    return start_date, end_date


def get_calendar_period(period: int, end_date: datetime) -> tuple[datetime, datetime]:
    if period == 7:
        # Align to the last full week (Monday to Sunday)
        start_date = (end_date - timedelta(days=end_date.weekday() + 7)
                      ).replace(hour=0, minute=0, second=0, microsecond=0)
        end_date = start_date + \
            timedelta(days=6, hours=23, minutes=59,
                      seconds=59, microseconds=999999)
    elif period == 30:
        # Align to the last full month
        first_day_of_current_month = end_date.replace(day=1)
        start_date = (first_day_of_current_month - timedelta(days=1)
                      ).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        last_day_of_last_month = first_day_of_current_month - timedelta(days=1)
        end_date = last_day_of_last_month.replace(
            hour=23, minute=59, second=59, microsecond=999999)
    elif period == 90:
        # Align to the last full quarter
        current_quarter = (end_date.month - 1) // 3 + 1
        first_day_of_current_quarter = datetime(
            end_date.year, 3 * current_quarter - 2, 1)
        start_date = (first_day_of_current_quarter - timedelta(days=1)
                      ).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        last_day_of_last_quarter = first_day_of_current_quarter - \
            timedelta(days=1)
        end_date = last_day_of_last_quarter.replace(
            hour=23, minute=59, second=59, microsecond=999999)
    else:
        raise ValueError("Unsupported period for calendar time window")
    return start_date, end_date


async def async_scheduler_to_tm_format(job_name):
    parts = job_name.split(':')
    if len(parts) >= 3:
        formatted_name = f"tm.{parts[0]}.{parts[1]}"
        formatted_name += "." + ".".join(parts[2:])
        logger.debug(
            f"Converted job name {job_name} to {formatted_name}")
        return formatted_name
    elif len(parts) == 2:
        formatted_name = f"tm.{parts[0]}.{parts[1]}"
        logger.debug(
            f"Converted job name {job_name} to {formatted_name}")
        return formatted_name
    else:
        return "tm.tasks.common"


async def async_tm_to_scheduler_format(job_name):
    if job_name.startswith("tm."):
        parts = job_name[3:].split('.')
        if len(parts) >= 2:
            formatted_name = f"{parts[0]}:{parts[1]}"
            if len(parts) > 2:
                formatted_name += ":" + ":".join(parts[2:])
            logger.debug(
                f"Converted job name {job_name} to {formatted_name}")
            return formatted_name
        else:
            raise ValueError("Invalid format for conversion")
    else:
        raise ValueError("Job name must start with 'tm.' for this conversion")


async def extract_job_alias(name):
    if name.startswith("tm."):
        parts = name.split('.')
        if len(parts) >= 4:
            return parts[-1]
        else:
            return None  # Or handle the case where there's no last part
    else:
        parts = name.split(':')
        if len(parts) >= 3:
            return parts[-1]
        else:
            return None  # Or handle the case where there's no last part

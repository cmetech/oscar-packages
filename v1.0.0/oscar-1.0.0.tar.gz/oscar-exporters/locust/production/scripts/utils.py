import os
import random
import csv
import time
import string
import mysql.connector

# Read the CSV file and extract IDs
def read_csv_file(file_path):
    ids = []
    with open(file_path, 'r') as csv_file:
        csv_reader = csv.reader(csv_file)
        next(csv_reader)  # Skip the header row if present
        for row in csv_reader:
            ids.append(row[0])  # Assuming the ID column is the first column (change it if needed)
    return ids

# Replace the placeholder with a random ID from the CSV file
def collect_finnumber(csv_file_path):
    ids = read_csv_file(csv_file_path)
    random_id = random.choice(ids)
    return random_id

# Replace the placeholder with a random ID from the CSV file
def collect_msisdn(csv_file_path):
    ids = read_csv_file(csv_file_path)
    random_id = random.choice(ids)
    return random_id

def generate_random_string(length):
    prefix = "ABCD234"
    characters = string.ascii_letters + string.digits
    random_string = prefix + ''.join(random.choice(characters) for _ in range(length - len(prefix)))
    #print(f"random string = {random_string}")
    return random_string

def get_random_id_from_mysql(dbconn_obj):
        cursor = dbconn_obj.cursor()
        try:
            #connection = mysql.connector.connect(host=hostip, user=user, password=password, database=database)         
            cursor.execute("SELECT finAccNumbers FROM FinAccountNumbers ORDER BY RAND() LIMIT 1")
            result = cursor.fetchone()
            print(f"get_random_id_from_mysql : the account number = {result[0]}")
            return result[0] if result else None
        finally:
            cursor.close()
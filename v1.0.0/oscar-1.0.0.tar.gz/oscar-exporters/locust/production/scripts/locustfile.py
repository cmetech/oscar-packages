import os
import mysql.connector
from locust import HttpUser, task, between
from prometheus_client import CollectorRegistry, Gauge, push_to_gateway
from soap_requests import financialAccountSearch as fin_acc_api
from soap_requests import getFinancialAccountDetails as fin_acc_details
from soap_requests import getPrepaidBalance as get_prepaid_balance_api
from soap_requests import getUsageSummary as get_usage_summary_api
import random
import csv
from datetime import datetime

# Initialize the counter to the starting value
fin_acc_search_counter = 1000000000
get_fin_acc_details_counter = 1000000000
get_prepaid_balance_counter = 1000000000
get_usage_summary_counter = 1000000000


def generate_incrementing_id(counter):
    counter += 1
    print(f"The counter = {counter}")
    return counter


# Initialize Prometheus metrics
registry = CollectorRegistry()
oscar_api_availability = Gauge("oscar_api_availability", "SLA 4.0.1 API availability (1 for success, 0 for failure)", [
                               "sla", "api"], registry=registry)


'''
SLA 4.0.1
'''


class WSILSoapApi(HttpUser):
    wait_time = between(1, 5)  # Wait time between tasks (1-5 seconds)
    wsil_host = os.environ.get("WSIL_HOST")
    wsil_port = os.environ.get("WSIL_PORT")

    host = f"{wsil_host}:{wsil_port}"

    def on_start(self):
        hostip = os.getenv("LOCUST_DB_HOST")
        user = os.getenv("LOCUST_DB_USER")
        pwd_file = os.getenv("LOCUST_PASSWORD_FILE")
        oscar_pwd = None
        database = os.getenv("LOCUST_DB")

        if oscar_pwd is None:
            with open(pwd_file, 'r') as file:
                oscar_pwd = file.readline().strip()
                print("reading the oscar pwd")

        self.db_connection = mysql.connector.connect(
            host=hostip, user=user, password=oscar_pwd, database=database)

    def on_stop(self):
        if hasattr(self, 'db_connection') and self.db_connection.is_connected():
            print("Closing the db connection")
            self.db_connection.close()

    @task
    def soap_api_fin_acc_search(self):
        # Define the SOAP request with the selected account number
        soap_request = fin_acc_api.generate_soap_request(self.db_connection)

        global fin_acc_search_counter
        fin_acc_search_counter = generate_incrementing_id(
            fin_acc_search_counter)

        # Define headers for the SOAP request
        headers = {
            "Content-Type": "text/xml",
            "SOAPAction": "financialAccountSearch",  # Replace with the actual SOAP action
            "SYN-TRAFFIC": "True",
            "APINAME": "financialAccountSearch",
            "INTERID": datetime.now().strftime("%Y%m%d%H%M"),
            "TRANSID": f"JMETER01FAS{fin_acc_search_counter}",
            "CLIENTNAME": "JMETER-AWS-PolarisProd"
        }

        # Send the SOAP request using HTTP POST
        response = self.client.post(
            "/services/CustomerDataWSIL", data=soap_request, headers=headers, verify=False)

        # Check if the request was successful
        if response.status_code == 200:
            # You can add assertions or log the response here
            oscar_api_availability.labels(
                sla="SLA4.0.1", api="financialAccountDetail").set(1)
            print("soap_api_fin_acc_search : SOAP request success")
        else:
            oscar_api_availability.labels(
                sla="SLA4.0.1", api="financialAccountDetail").set(0)
            print("soap_api_fin_acc_search: SOAP request failed with status code: {}".format(
                response.status_code))
        # print("Sending to pushgateway")
        push_to_gateway('pushgateway:9091',
                        job='oscar_sla401_availability', registry=registry)

    @task
    def soap_api_get_fin_acc_details(self):
        # Select a random account number
        # account_number = random.choice(self.account_numbers)[0]

        # Define the SOAP request with the selected account number
        soap_request = fin_acc_details.generate_soap_request(
            self.db_connection)

        global get_fin_acc_details_counter
        get_fin_acc_details_counter = generate_incrementing_id(
            get_fin_acc_details_counter)

        # Define headers for the SOAP request
        headers = {
            "Content-Type": "text/xml",
            # Replace with the actual SOAP action
            "SOAPAction": "getFinancialAccountDetails",
            "SYN-TRAFFIC": "True",
            "APINAME": "getFinancialAccountDetails",
            "INTERID": datetime.now().strftime("%Y%m%d%H%M"),
            "TRANSID": f"JMETER02GFD{get_fin_acc_details_counter}",
            "CLIENTNAME": "JMETER-AWS-PolarisProd"
        }

        # Send the SOAP request using HTTP POST
        response = self.client.post(
            "/services/FinancialAccountDetailsWSIL", data=soap_request, headers=headers, verify=False)

        # Check if the request was successful
        if response.status_code == 200:
            # You can add assertions or log the response here
            oscar_api_availability.labels(
                sla="SLA4.0.1", api="getFinancialAccountDetails").set(1)
        else:
            oscar_api_availability.labels(
                sla="SLA4.0.1", api="getFinancialAccountDetails").set(0)
            # print("SOAP request failed with status code: {}".format(response.status_code))
        push_to_gateway('pushgateway:9091',
                        job='oscar_sla401_availability', registry=registry)

    @task
    def soap_api_get_prepaid_balance(self):
        # Select a random account number
        # account_number = random.choice(self.account_numbers)[0]

        # Define the SOAP request with the selected account number
        soap_request = get_prepaid_balance_api.generate_soap_request(
            self.db_connection)

        global get_prepaid_balance_counter
        get_prepaid_balance_counter = generate_incrementing_id(
            get_prepaid_balance_counter)

        # Define headers for the SOAP request
        headers = {
            "Content-Type": "text/xml",
            "SOAPAction": "getPrepaidBalance",  # Replace with the actual SOAP action
            "SYN-TRAFFIC": "True",
            "APINAME": "getFinancialAccountDetails",
            "INTERID": datetime.now().strftime("%Y%m%d%H%M"),
            "TRANSID": f"JMETER03GPB{get_prepaid_balance_counter}",
            "CLIENTNAME": "JMETER-AWS-PolarisProd"
        }

        # Send the SOAP request using HTTP POST
        response = self.client.post(
            "/services/FinancialAccountWSIL", data=soap_request, headers=headers, verify=False)

        # Check if the request was successful
        if response.status_code == 200:
            # You can add assertions or log the response here
            oscar_api_availability.labels(
                sla="SLA4.0.1", api="getPrepaidBalance").set(1)
        else:
            oscar_api_availability.labels(
                sla="SLA4.0.1", api="getPrepaidBalance").set(0)
            # print("SOAP request failed with status code: {}".format(response.status_code))
        push_to_gateway('pushgateway:9091',
                        job='oscar_sla401_availability', registry=registry)

    @task
    def soap_api_get_usage_summary(self):
        # Select a random account number
        # account_number = random.choice(self.account_numbers)[0]

        # Define the SOAP request with the selected account number
        soap_request = get_usage_summary_api.generate_soap_request(
            self.db_connection)

        global get_usage_summary_counter
        get_usage_summary_counter = generate_incrementing_id(
            get_usage_summary_counter)

        # Define headers for the SOAP request
        headers = {
            "Content-Type": "text/xml",
            "SOAPAction": "getUsageSummary",  # Replace with the actual SOAP action
            "SYN-TRAFFIC": "True",
            "APINAME": "getUsageSummary",
            "INTERID": datetime.now().strftime("%Y%m%d%H%M"),
            "TRANSID": f"JMETER04GUS{get_usage_summary_counter}",
            "CLIENTNAME": "JMETER-AWS-PolarisProd"
        }

        # Send the SOAP request using HTTP POST
        response = self.client.post(
            "/services/UsageWSIL", data=soap_request, headers=headers, verify=False)

        # Check if the request was successful
        if response.status_code == 200:
            # You can add assertions or log the response here
            oscar_api_availability.labels(
                sla="SLA4.0.1", api="getUsageSummary").set(1)
        else:
            oscar_api_availability.labels(
                sla="SLA4.0.1", api="getUsageSummary").set(0)
            # print("SOAP request failed with status code: {}".format(response.status_code))
        push_to_gateway('pushgateway:9091',
                        job='oscar_sla401_availability', registry=registry)

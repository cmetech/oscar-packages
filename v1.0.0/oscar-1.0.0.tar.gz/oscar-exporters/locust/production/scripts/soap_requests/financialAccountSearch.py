from datetime import datetime
import utils

def generate_soap_request(dbconn_obj):
    tstamp = datetime.now().strftime('%Y-%m-%dT%H:%M:%S') + 'Z'
    #fin_acc_num = utils.collect_finnumber("/data/finAccNum.txt")
    fin_acc_num = utils.get_random_id_from_mysql(dbconn_obj)
    print(f"getFinancialAccSearch - fin account number = {fin_acc_num}")
    random_id = utils.generate_random_string(32)
    # Generate SOAP request 
    soap_request = f"""
    <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:v1="http://services.tmobile.com/CustomerManagement/CustomerDataWSIL/V1" xmlns:base="http://services.tmobile.com/base">
    <soapenv:Header/>:
    <soapenv:Body>
        <n0:financialAccountSearchRequest serviceTransactionId="${random_id}" xmlns:n0="http://services.tmobile.com/CustomerManagement/CustomerDataWSIL/V1" xmlns:n1="http://services.tmobile.com/base" xmlns:prx="urn:sap.com:proxy:UQ7:/1SAI/TAS561368C6A4862268E1B5:750" xmlns:soap-env="http://schemas.xmlsoap.org/soap/envelope/" xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/">
            <n1:header>
                <n1:sender>
                <n1:senderId>EHJMETER)</n1:senderId>
                <n1:channelId>$JMETER)</n1:channelId>
                <n1:applicationId>$JMETER)</n1:applicationId>
                <n1:applicationUserId>$TOOLS_TEAM)</n1:applicationUserId>
                <n1:sessionId>{random_id}</n1:sessionId>
                <n1:workflowId>CustomerDataWSIL.financialAccountSearch</n1:workflowId>
                <n1:activityId>{random_id}</n1:activityId>
                <n1:timestamp>{tstamp}</n1:timestamp>
                <n1:dealerCode>2211802</n1:dealerCode>
                <n1:interactionId>TOOLS_TEAM{random_id}</n1:interactionId>
                </n1:sender>
                <n1:target>
                <n1:targetSystemId>
                    <n1:systemId>WSIL</n1:systemId>
                    <n1:userId>TOOLS_TEAM</n1:userId>
                </n1:targetSystemId>
                <n1:userCompanyId>T-Mobile</n1:userCompanyId>
                <n1:servicePartnerId>TMO</n1:servicePartnerId>
                <n1:transactionType>CustomerDataWSIL.financialAccountSearch</n1:transactionType>
                </n1:target>
                <n1:providerId>
                <n1:contextId>IAM ID</n1:contextId>
                </n1:providerId>
            </n1:header>
            <n0:financialAccountNumber>${fin_acc_num}</n0:financialAccountNumber>
            <n0:resultSize>100</n0:resultSize>
            <n0:pageNumber>1</n0:pageNumber>
        </n0:financialAccountSearchRequest>
    </soapenv:Body>
    </soapenv:Envelope>
    """
    return soap_request
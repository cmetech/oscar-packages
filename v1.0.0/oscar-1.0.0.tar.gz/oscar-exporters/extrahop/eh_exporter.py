import os
import requests
import urllib3
from http.server import HTTPServer, BaseHTTPRequestHandler
from prometheus_client import start_http_server, Gauge
import time
import json

from sys import getsizeof
from datetime import datetime

# from data_maps import ec2_datamap, api_datamap
# Read the JSON configuration file

DATA_MAP = "/app/config/data_map.json"

if os.path.exists(DATA_MAP):
    with open(DATA_MAP) as config_file:
        config_data = json.load(config_file)

ec2_datamap = config_data["ec2_datamap"]
# api_datamap = config_data["api_datamap"]

# Dictionary to store Gauge metrics
gauge_metrics = {}
metric_resp_name = "oscar_api_responsetime"
metric_volume_name = "oscar_api_volume"

# Define the path to the secret
secret_path = "/run/secrets/eh_apikey"

# Read the content of the file
EDA_APIKEY = ""
with open(secret_path, "r") as file:
    EDA_APIKEY = file.read().strip()

# Constants
DATACENTER = os.environ.get("DATACENTER", "polaris")
ENVIRONMENT = os.environ.get("ENVIRONMENT", "production")
EDA_HOST = os.environ.get("EH_HOST")
EDA_PORT = int(os.environ.get("EH_PORT", 8000))
EH_SLEEP_TIME = int(os.environ.get("EH_SLEEP_TIME", 30))
EH_LOG_LEVEL = os.environ.get("EH_LOG_LEVEL", "INFO").lower()

EH_METRIC_BY_OBJECT_PATH = "/api/v1/metrics/totalbyobject"
EH_DEVICES_SEARCH_PATH = "/api/v1/devices/search"


def collect_eh_resptime_metrics():
    if EH_LOG_LEVEL == "debug":
        print("Collecting response time metrics...")
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    headers = {
        "Content-Type": "application/json",
        "Authorization": "ExtraHop apikey=" + str(EDA_APIKEY),
    }

    # filter records if key starts with "i-" or "none"
    filterd_datamap = {k: v for k, v in ec2_datamap.items() if not k.startswith("i-")}
    device_ids = [
        int(v.get("eh_id"))
        for k, v in filterd_datamap.items()
        if not v["eh_id"].startswith("None")
    ]

    with requests.Session() as s:
        s.headers.update(headers)

        body = {
            "cycle": "auto",
            "from": "-5m",
            "metric_category": "custom_detail",
            "metric_specs": [
                {
                    "name": "APIPROCTIMEPERDEVICEBYOP",
                    "calc_type": "percentiles",
                    "percentiles": [98],
                }
            ],
            "object_ids": device_ids,
            "object_type": "device",
            "until": 0,
        }

        # retrieve metrics
        url = "https://" + EDA_HOST + EH_METRIC_BY_OBJECT_PATH
        rsp = s.post(url, json=body, verify=False)

        eh_data = rsp.json()
        if eh_data and rsp.status_code == 200:
            eh_data = rsp.json()
            stats_details = eh_data["stats"]
            # print("stat_details =",stats_details)
            if stats_details:
                for idx_0, stats_entry in enumerate(stats_details):
                    object_id = stats_entry["oid"]
                    dev_details = ec2_datamap[str(object_id)]
                    ip_address = dev_details["ip"]
                    hostname = dev_details["host"]
                    component = dev_details["stack"]
                    # availability_zone = dev_details["zone"]
                    host_env = ENVIRONMENT.lower()

                    values_details = stats_entry["values"]
                    for idx_1, values_entry in enumerate(values_details):
                        if len(values_entry) > 0:
                            value_details = values_entry[idx_1]["value"]
                            for idx_2, value_entry in enumerate(value_details):
                                opname = value_entry["key"]["str"]
                                opvalue = value_entry["value"][0]

                                # Service name
                                # service_name = "None"
                                # key = component.lower() + "." + opname.lower()

                                # # check for existence of API
                                # if key in api_datamap:
                                #     service_name = api_datamap[key]["service"]

                                metric_value = float(opvalue)

                                # Create or get existing Gauge metric with metric_name as label
                                if metric_resp_name not in gauge_metrics:
                                    gauge_metrics[metric_resp_name] = Gauge(
                                        metric_resp_name,
                                        f"Response time for {metric_resp_name} operation",
                                        [
                                            "environment",
                                            "api_name",
                                            "hostname",
                                            "component",
                                            "ip_address",
                                            "metric_type",
                                        ],
                                    )
                                # Set the metric value and labels
                                gauge_metrics[metric_resp_name].labels(
                                    environment=host_env.lower(),
                                    api_name=opname.lower(),
                                    hostname=hostname.lower(),
                                    component=component.lower(),
                                    ip_address=ip_address,
                                    metric_type="performance",
                                ).set(metric_value)

                                # Print the metric value and labels for debugging (optional)
                                if EH_LOG_LEVEL == "debug":
                                    print(
                                        f"Response time {metric_resp_name} - Environment: {host_env.lower()}, Api_name: {opname.lower()}. Hostname: {hostname}, Component: {component}, Value: {metric_value}"
                                    )  # noqa E501
            else:
                print("No Stats Received")  # noqa E501
        else:
            print("No Data Received")


def collect_eh_volume_metrics():
    # print("Collecting volume metrics...")
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    headers = {
        "Content-Type": "application/json",
        "Authorization": "ExtraHop apikey=" + str(EDA_APIKEY),
    }

    # filter records if key starts with "i-" or "none"
    filterd_datamap = {k: v for k, v in ec2_datamap.items() if not k.startswith("i-")}
    device_ids = [
        int(v.get("eh_id"))
        for k, v in filterd_datamap.items()
        if not v["eh_id"].startswith("None")
    ]

    with requests.Session() as s:
        s.headers.update(headers)

        body = {
            "cycle": "auto",
            "from": "-5m",
            "metric_category": "custom_detail",
            "metric_specs": [
                {
                    "name": "APICOUNTBYOP",
                }
            ],
            "object_ids": device_ids,
            "object_type": "device",
            "until": 0,
        }

        # retrieve metrics
        url = "https://" + EDA_HOST + EH_METRIC_BY_OBJECT_PATH
        rsp = s.post(url, json=body, verify=False)

        eh_data = rsp.json()
        if eh_data and rsp.status_code == 200:
            eh_data = rsp.json()
            stats_details = eh_data["stats"]
            # print("stat_details =",stats_details)
            if stats_details:
                for idx_0, stats_entry in enumerate(stats_details):
                    object_id = stats_entry["oid"]
                    dev_details = ec2_datamap[str(object_id)]
                    ip_address = dev_details["ip"]
                    hostname = dev_details["host"]
                    component = dev_details["stack"]
                    # availability_zone = dev_details["zone"]
                    host_env = ENVIRONMENT.lower()

                    values_details = stats_entry["values"]
                    for idx_1, values_entry in enumerate(values_details):
                        if len(values_entry) > 0:
                            value_details = values_entry[idx_1]["value"]
                            for idx_2, value_entry in enumerate(value_details):
                                opname = value_entry["key"]["str"]
                                opvalue = value_entry["value"]

                                # # Splunk metric format
                                # service_name = "None"
                                # key = component.lower() + "." + opname.lower()
                                # # check for existence of API
                                # if key in api_datamap:
                                #     service_name = api_datamap[key]["service"]

                                metric_value = float(opvalue)

                                # Create or get existing Gauge metric with metric_name as label
                                if metric_volume_name not in gauge_metrics:
                                    gauge_metrics[metric_volume_name] = Gauge(
                                        metric_volume_name,
                                        f"Response time for {metric_volume_name} operation",
                                        [
                                            "environment",
                                            "api_name",
                                            "hostname",
                                            "component",
                                            "ip_address",
                                            "metric_type",
                                        ],
                                    )
                                # Set the metric value and labels
                                gauge_metrics[metric_volume_name].labels(
                                    environment=host_env.lower(),
                                    api_name=opname.lower(),
                                    hostname=hostname.lower(),
                                    component=component.lower(),
                                    ip_address=ip_address,
                                    metric_type="performance",
                                ).set(metric_value)

                                # Print the metric value and labels for debugging (optional)
                                if EH_LOG_LEVEL == "debug":
                                    print(
                                        f"Volume counts {metric_volume_name} - Environment: {host_env.lower()}, Api_name: {opname.lower()}. Hostname: {hostname}, Component: {component}, Value: {metric_value}"
                                    )
            else:
                print("No Stats Received")
        else:
            print("No Data Received")


if __name__ == "__main__":
    # Start the HTTP server to expose metrics
    start_http_server(EDA_PORT, addr="0.0.0.0")
    print("Started HTTP server on port " + str(EDA_PORT))

    # Main loop to simulate processing requests
    while True:
        # print("Collecting metrics...")
        collect_eh_resptime_metrics()
        time.sleep(1)
        collect_eh_volume_metrics()
        time.sleep(EH_SLEEP_TIME)

#!/bin/bash

# Initialize default values
TAG="latest"
PLATFORM="linux/amd64"
IMAGE_NAME="oscar/ehexporter-amd64"

# Parse command-line arguments
while getopts "c:t:v:" opt; do
    case $opt in
        c)
            # Remove the docker image
            docker rmi -f "${IMAGE_NAME}:${OPTARG}"
            exit 0
            ;;
        t)
            TAG="${OPTARG}"
            ;;
        *)
            # Invalid option
            echo "Invalid option: -$OPTARG" >&2
            exit 1
            ;;
    esac
done

# Build the Docker image
docker build --platform "${PLATFORM}" -t "${IMAGE_NAME}:${TAG}" .

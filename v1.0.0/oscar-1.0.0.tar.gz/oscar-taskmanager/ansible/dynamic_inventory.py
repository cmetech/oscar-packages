#!/usr/bin/env python

import json
import httpx
import argparse

# URL of the inventory API
API_URL = "https://middleware:5200/api/v1/inventory/export/targets"


def sanitize_group_name(name):
    """Sanitize the group name to be compatible with Ansible's naming conventions."""
    # Remove non-ASCII characters
    name = ''.join(char for char in name if char.isascii())
    # Replace spaces and hyphens with underscores and strip leading/trailing spaces
    return name.strip().replace(" ", "_").replace("-", "_").replace("\xa0", "_")


def fetch_inventory():
    with httpx.Client(verify=False) as client:
        try:
            # Make a GET request to fetch the inventory with type=ansible
            params = {"type": "ansible"}
            response = client.get(API_URL, params=params)
            # Check if the request was successful
            if response.status_code == 200:
                data = response.json()
                # Sanitize the inventory data
                sanitized_data = sanitize_inventory(data)
                return sanitized_data
            else:
                print(f"Error fetching inventory: HTTP {response.status_code}")
                return {}
        except httpx.RequestError as e:
            print(f"An error occurred while requesting {e.request.url!r}.")
            return {}


def sanitize_inventory(data):
    """Sanitize all group names in the inventory."""
    sanitized_data = {}
    for key, value in data.items():
        sanitized_key = sanitize_group_name(key)
        if isinstance(value, dict):
            sanitized_data[sanitized_key] = {k: v if k != 'children' else [
                sanitize_group_name(child) for child in v] for k, v in value.items()}
            if 'hosts' in value:  # Ensure hosts list is directly under sanitized group
                sanitized_data[sanitized_key]['hosts'] = value['hosts']
        else:
            sanitized_data[sanitized_key] = value
    return sanitized_data


def main():
    parser = argparse.ArgumentParser(
        description='Ansible dynamic inventory script.')
    parser.add_argument('--list', action='store_true',
                        help='List all groups and hosts')
    parser.add_argument(
        '--host', help='Get all the variables about a specific host')

    args = parser.parse_args()

    if args.list:
        # Fetch and print the entire inventory
        inventory = fetch_inventory()
        print(json.dumps(inventory))
    elif args.host:
        # For now, return an empty object for specific host requests
        print(json.dumps({}))
    else:
        # If no arguments are provided, or unsupported arguments are used, show help
        parser.print_help()


if __name__ == '__main__':
    main()

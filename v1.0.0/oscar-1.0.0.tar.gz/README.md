# Installing Docker on Red Hat/CentOS

## Step 1: Update the System

First, ensure your system is up to date.

```bash
sudo yum update -y
```

## Step 2: Install Required Packages

Install the necessary packages for Docker.

```bash
sudo yum install -y yum-utils device-mapper-persistent-data lvm2
```

## Step 3: Add Docker Repository

Add the Docker repository to your system.

```bash
sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
```

## Step 4: Install Docker

Install Docker CE (Community Edition)

```bash
sudo yum install -y docker-ce docker-ce-cli containerd.io
```

## Step 5: Start and Enable Docker

Start the Docker service and enable it to start on boot

```bash
sudo systemctl start docker
sudo systemctl enable docker
```

## Step 6: Verify Docker Installation

Verify that Docker CE is installed correctly by running the hello-world image.

```bash
sudo docker run hello-world
```

## Step 7: Add User to Docker Group

Add the current user to the docker group.

```bash
sudo usermod -aG docker $USER
```


